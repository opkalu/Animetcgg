import asyncio
from database.db import db

async def migrate():
    await db.connect()
    print("⏳ Fixing Guild Database...")
    
    # Forcefully add the missing columns
    try:
        await db.execute("ALTER TABLE guilds ADD COLUMN IF NOT EXISTS buff_xp INT DEFAULT 0;")
        await db.execute("ALTER TABLE guilds ADD COLUMN IF NOT EXISTS buff_dmg INT DEFAULT 0;")
        print("✅ Added 'buff_xp' and 'buff_dmg' columns!")
    except Exception as e:
        print(f"⚠️ Error (might already exist): {e}")

    print("✅ Database Repair Complete.")

if __name__ == "__main__":
    asyncio.run(migrate())
