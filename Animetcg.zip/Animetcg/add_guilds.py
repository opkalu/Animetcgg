import asyncio
from database.db import db

async def migrate():
    await db.connect()
    print("⏳ Constructing Guild System...")
    
    # 1. Guilds Table
    await db.execute("""
        CREATE TABLE IF NOT EXISTS guilds (
            guild_id SERIAL PRIMARY KEY,
            name TEXT UNIQUE,
            leader_id BIGINT,
            level INT DEFAULT 1,
            xp INT DEFAULT 0,
            funds BIGINT DEFAULT 0,
            buff_xp INT DEFAULT 0,
            buff_dmg INT DEFAULT 0
        );
    """)

    # 2. Members Table (Links User -> Guild)
    await db.execute("""
        CREATE TABLE IF NOT EXISTS guild_members (
            user_id BIGINT PRIMARY KEY,
            guild_id INT,
            role TEXT DEFAULT 'Member' 
        );
    """)
    
    print("✅ Guilds Founded!")

if __name__ == "__main__":
    asyncio.run(migrate())
