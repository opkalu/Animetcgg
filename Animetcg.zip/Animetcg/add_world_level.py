import asyncio
from database.db import db

async def migrate():
    await db.connect()
    print("⏳ Adding World Level System...")
    
    # 1. Add 'level' to raid_boss table (tracks Boss Strength)
    await db.execute("ALTER TABLE raid_boss ADD COLUMN IF NOT EXISTS level INT DEFAULT 1;")
    
    # 2. Add 'boss_id' (to track unique mechanics)
    await db.execute("ALTER TABLE raid_boss ADD COLUMN IF NOT EXISTS boss_type TEXT DEFAULT 'Madara';")

    print("✅ World Level System Installed!")

if __name__ == "__main__":
    asyncio.run(migrate())
