import asyncio
from database.db import db

async def migrate():
    await db.connect()
    print("⏳ Adding Boss Elements...")
    
    # Add 'element' column
    await db.execute("ALTER TABLE raid_boss ADD COLUMN IF NOT EXISTS element TEXT DEFAULT 'Neutral';")
    
    # Update Madara to be Fire
    await db.execute("UPDATE raid_boss SET element = 'Fire' WHERE name LIKE '%Madara%';")
    
    print("✅ Boss is now Elemental!")

if __name__ == "__main__":
    asyncio.run(migrate())
