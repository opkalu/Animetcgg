import asyncio
from database.db import db

async def migrate():
    await db.connect()
    print("⏳ Creating Pet System...")
    
    # user_id: Owner
    # pet_type: 'Slime' (Economy), 'Dragon' (Combat), 'Golem' (Defense)
    # nickname: Custom name
    # hunger: 0-100 (If 0, pet provides no bonus)
    await db.execute("""
        CREATE TABLE IF NOT EXISTS pets (
            user_id BIGINT PRIMARY KEY,
            pet_type TEXT NOT NULL,
            nickname TEXT DEFAULT 'Pet',
            hunger INT DEFAULT 100,
            created_at TIMESTAMP DEFAULT NOW()
        );
    """)
    
    print("✅ Pet System Ready!")

if __name__ == "__main__":
    asyncio.run(migrate())
