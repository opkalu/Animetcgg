import asyncio
from database.db import db

async def migrate():
    await db.connect()
    print("⏳ Upgrading Database to God-Tier...")

    # 1. Add Element Column
    await db.execute("ALTER TABLE cards ADD COLUMN IF NOT EXISTS element TEXT DEFAULT 'Neutral';")

    # 2. Randomly assign elements to existing cards so they aren't boring
    # (Fire, Water, Leaf cycle)
    await db.execute("UPDATE cards SET element = 'Fire' WHERE card_id % 3 = 0;")
    await db.execute("UPDATE cards SET element = 'Water' WHERE card_id % 3 = 1;")
    await db.execute("UPDATE cards SET element = 'Leaf' WHERE card_id % 3 = 2;")
    
    print("✅ Database Upgraded! Elements assigned.")

if __name__ == "__main__":
    asyncio.run(migrate())
