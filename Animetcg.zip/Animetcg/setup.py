import asyncio
from database.db import db

async def setup():
    print("⏳ Connecting to database...")
    await db.connect()
    
    print("🛠️ Creating Tables...")

    # 1. USERS
    await db.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id BIGINT PRIMARY KEY,
            username TEXT,
            coins BIGINT DEFAULT 100,
            wins INT DEFAULT 0,
            losses INT DEFAULT 0,
            last_daily TIMESTAMP
        );
    """)

    # 2. CARDS
    await db.execute("""
        CREATE TABLE IF NOT EXISTS cards (
            card_id SERIAL PRIMARY KEY,
            name TEXT UNIQUE,
            rarity INT,
            anime_source TEXT,
            element TEXT DEFAULT 'Neutral',
            image_url TEXT
        );
    """)

    # 3. USER COLLECTION
    await db.execute("""
        CREATE TABLE IF NOT EXISTS user_cards (
            id SERIAL PRIMARY KEY,
            user_id BIGINT REFERENCES users(user_id),
            card_id INT REFERENCES cards(card_id),
            obtained_at TIMESTAMP DEFAULT NOW()
        );
    """)

    # 4. GUILDS
    await db.execute("""
        CREATE TABLE IF NOT EXISTS guilds (
            guild_id SERIAL PRIMARY KEY,
            name TEXT UNIQUE,
            leader_id BIGINT,
            coins BIGINT DEFAULT 0,
            level INT DEFAULT 1,
            description TEXT DEFAULT 'No description'
        );
    """)

    # 5. GUILD MEMBERS
    await db.execute("""
        CREATE TABLE IF NOT EXISTS guild_members (
            user_id BIGINT PRIMARY KEY,
            guild_id INT REFERENCES guilds(guild_id) ON DELETE CASCADE,
            rank TEXT DEFAULT 'Member'
        );
    """)

    # 6. BOUNTIES
    await db.execute("""
        CREATE TABLE IF NOT EXISTS bounties (
            user_id BIGINT PRIMARY KEY,
            amount BIGINT DEFAULT 0
        );
    """)

    # 7. PROMO CODES
    await db.execute("""
        CREATE TABLE IF NOT EXISTS promo_codes (
            code TEXT PRIMARY KEY,
            reward INT,
            uses_left INT
        );
    """)

    # 8. REDEEMED CODES
    await db.execute("""
        CREATE TABLE IF NOT EXISTS redeemed_codes (
            user_id BIGINT,
            code TEXT,
            PRIMARY KEY (user_id, code)
        );
    """)

    # 9. PETS
    await db.execute("""
        CREATE TABLE IF NOT EXISTS pets (
            user_id BIGINT PRIMARY KEY,
            pet_type TEXT,
            nickname TEXT DEFAULT 'Pet',
            hunger INT DEFAULT 100
        );
    """)

    print("✅ ALL TABLES CREATED SUCCESSFULLY!")
    print("🚀 You can now run 'python bot.py'")

if __name__ == "__main__":
    asyncio.run(setup())
