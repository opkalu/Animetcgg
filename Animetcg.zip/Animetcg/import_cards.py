import asyncio
import os
from database.db import db

FOLDER = "assets/cards"

async def mass_import():
    await db.connect()
    print(f"📂 Scanning {FOLDER}...")
    
    files = os.listdir(FOLDER)
    count = 0
    
    for filename in files:
        if not filename.endswith(".jpg"): continue
            
        try:
            # Format: Name__Rarity__Element__Anime.jpg
            base = filename.rsplit('.', 1)[0]
            parts = base.split('__')
            
            if len(parts) != 4:
                print(f"⚠️ Skipping {filename}: Name format wrong.")
                continue
                
            name = parts[0].replace("_", " ") # Restore spaces
            rarity = int(parts[1])
            element = parts[2]
            anime = parts[3].replace("_", " ")
            
            image_path = f"{FOLDER}/{filename}"
            
            # Upsert (Update if exists, Insert if new)
            exists = await db.fetchval("SELECT 1 FROM cards WHERE name = $1", name)
            if exists:
                await db.execute("""
                    UPDATE cards SET image_url=$1, rarity=$2, element=$3, anime=$4 WHERE name=$5
                """, image_path, rarity, element, anime, name)
                print(f"🔄 Updated: {name}")
            else:
                await db.execute("""
                    INSERT INTO cards (name, rarity, anime, image_url, element)
                    VALUES ($1, $2, $3, $4, $5)
                """, name, rarity, anime, image_path, element)
                print(f"✅ Imported: {name}")
                count += 1
                
        except Exception as e:
            print(f"⚠️ Error on {filename}: {e}")

    print(f"\n🎉 Imported {count} cards.")

if __name__ == "__main__":
    asyncio.run(mass_import())

