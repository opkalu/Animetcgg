import asyncio
from database.db import db

async def migrate():
    await db.connect()
    print("⏳ Adding 'file_id' column to database...")
    try:
        # This column will store the Telegram ID permanently
        await db.execute("ALTER TABLE cards ADD COLUMN IF NOT EXISTS file_id TEXT;")
        print("✅ Database upgraded! Now it can remember File IDs.")
    except Exception as e:
        print(f"⚠️ Error: {e}")

if __name__ == "__main__":
    asyncio.run(migrate())
