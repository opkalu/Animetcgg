import asyncio
import os
import logging
from aiogram import Bot, Dispatcher, types
from aiogram.filters import CommandStart
from dotenv import load_dotenv

# --- DATABASE ---
from database.db import db

# --- HANDLERS ---
# Make sure ALL 16 of these files exist in 'handlers/'
from handlers import (
    admin, 
    submit, 
    market, 
    daily, 
    leaderboard, 
    gacha, 
    inventory,
    fusion, 
    battle,
    raid,
    raid_shop,  # 💀 Black Market
    codes,
    guild,      # 🏰 Clan System
    bounty,
    pet,
    train,      # 🥋 Dojo
    help        # 📖 Guide
)

# Load environment variables
load_dotenv()
TOKEN = os.getenv("BOT_TOKEN")

# Configure logging
logging.basicConfig(level=logging.INFO)

# Initialize Bot
bot = Bot(token=TOKEN)
dp = Dispatcher()

# --- REGISTER ROUTERS ---
# The order matters slightly. Admin usually goes first.
dp.include_router(admin.router)        # Admin Controls
dp.include_router(submit.router)       # Create Cards
dp.include_router(market.router)       # Global Economy
dp.include_router(daily.router)        # Daily Rewards
dp.include_router(leaderboard.router)  # Rankings
dp.include_router(gacha.router)        # Pull Cards
dp.include_router(inventory.router)    # View Bag
dp.include_router(fusion.router)       # Merge Cards
dp.include_router(battle.router)       # PVP Logic
dp.include_router(raid.router)         # Raid Boss
dp.include_router(raid_shop.router)    # Raid Shop
dp.include_router(codes.router)        # Promo Codes
dp.include_router(guild.router)        # Clan System
dp.include_router(bounty.router)       # Bounty Hunting
dp.include_router(pet.router)          # Pet System
dp.include_router(train.router)        # Training Dojo
dp.include_router(help.router)         # Help Command

@dp.message(CommandStart())
async def cmd_start(message: types.Message):
    user_id = message.from_user.id
    full_name = message.from_user.full_name
    username = message.from_user.username

    # Check/Register User
    user_exists = await db.fetchval("SELECT 1 FROM users WHERE user_id = $1", user_id)
    
    if not user_exists:
        # Create new user with 100 starter coins
        await db.execute(
            "INSERT INTO users (user_id, username, coins) VALUES ($1, $2, $3)",
            user_id, username, 100
        )
        await message.answer(
            f"🌟 <b>Welcome {full_name}!</b>\n\n"
            "You have been registered as a Hunter.\n"
            "💰 <b>Starting Balance:</b> 100 coins\n\n"
            "<b>📜 Quick Start:</b>\n"
            "• /pull - Get your first card (100c)\n"
            "• /train - Level it up 🥋\n"
            "• /raid - Fight the World Boss 👹\n"
            "• /help - See all commands",
            parse_mode="HTML"
        )
    else:
        # Welcome back existing user
        coins = await db.fetchval("SELECT coins FROM users WHERE user_id = $1", user_id)
        tokens = await db.fetchval("SELECT raid_tokens FROM users WHERE user_id = $1", user_id) or 0
        
        await message.answer(
            f"👋 <b>Welcome back, Hunter {full_name}!</b>\n"
            f"💰 Coins: {coins}\n"
            f"💀 Tokens: {tokens}\n\n"
            "<b>Ready for action?</b>\n"
            "Type <code>/raid</code> to check the boss status,\n"
            "or <code>/guild</code> to check your clan.",
            parse_mode="HTML"
        )

async def main():
    # 1. Connect to Database
    try:
        await db.connect()
        print("✅ Database Connected Successfully")
    except Exception as e:
        print(f"❌ Database Connection Failed: {e}")
        return

    # 2. Clear old pending updates
    await bot.delete_webhook(drop_pending_updates=True)
    
    print("🤖 Bot is now Online! All Systems Green.")
    try:
        await dp.start_polling(bot)
    finally:
        if db.pool:
            await db.pool.close()
            print("🛑 Database connection closed.")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        print("\n🛑 Bot stopped!")
