import asyncio
import os
from database.db import db

async def diagnose():
    await db.connect()
    print("🕵️ DIAGNOSING MISSING IMAGES...\n")
    
    # Fetch all cards
    cards = await db.fetch("SELECT name, image_url FROM cards")
    
    issues = 0
    for card in cards:
        name = card['name']
        path = card['image_url']
        
        # 1. Check if path is empty
        if not path:
            print(f"❌ [MISSING PATH] {name}: Database has NULL image_url")
            issues += 1
            continue
            
        # 2. Check if it's a URL (http)
        if path.startswith("http"):
            print(f"⚠️ https://www.merriam-webster.com/dictionary/link {name}: {path} (Bot must download this every time)")
            continue
            
        # 3. Check if file exists locally
        if not os.path.exists(path):
            print(f"🚫 [FILE NOT FOUND] {name}")
            print(f"   👉 DB expects: {path}")
            print(f"   👉 Actual folder content: {os.listdir(os.path.dirname(path)) if os.path.exists(os.path.dirname(path)) else 'Folder missing'}")
            issues += 1
        else:
            # File exists! Check size
            size = os.path.getsize(path)
            if size < 100: # Less than 100 bytes is suspicious
                print(f"⚠️ [CORRUPT FILE] {name}: File is too small ({size} bytes)")
                issues += 1
            else:
                print(f"✅ [OK] {name}")

    print(f"\nDiagnosis Complete. Found {issues} issues.")

if __name__ == "__main__":
    asyncio.run(diagnose())
