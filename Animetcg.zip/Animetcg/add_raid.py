import asyncio
from database.db import db

async def migrate():
    await db.connect()
    print("⏳ Creating Raid System...")
    
    # 1. Table for the Active Boss
    await db.execute("""
        CREATE TABLE IF NOT EXISTS raid_boss (
            id SERIAL PRIMARY KEY,
            name TEXT,
            image_url TEXT,
            hp BIGINT,
            max_hp BIGINT,
            is_active BOOLEAN DEFAULT TRUE
        );
    """)

    # 2. Table to track Player Damage (Leaderboard)
    await db.execute("""
        CREATE TABLE IF NOT EXISTS raid_logs (
            user_id BIGINT,
            damage BIGINT DEFAULT 0,
            PRIMARY KEY (user_id)
        );
    """)
    
    # 3. Insert a Dummy Boss if none exists
    exists = await db.fetchval("SELECT 1 FROM raid_boss")
    if not exists:
        await db.execute("""
            INSERT INTO raid_boss (name, image_url, hp, max_hp)
            VALUES ('Madara Uchiha', 'https://media1.tenor.com/m/7y2j5vG3aowAAAAC/madara-uchiha-fire.gif', 50000, 50000)
        """)
    
    print("✅ Boss Spawned!")

if __name__ == "__main__":
    asyncio.run(migrate())
