import asyncio
from database.db import db

async def seed():
    await db.connect()
    
    # 1=Common, 2=Rare, 3=Epic, 4=Legendary, 5=Mythic
    cards = [
        ("Ichigo Kurosaki", 2, "Bleach", "https://i.imgur.com/8Q9ZX4A.jpg"),
        ("Naruto Uzumaki", 3, "Naruto", "https://i.imgur.com/Gj9Zq9s.jpg"),
        ("Monkey D. Luffy", 4, "One Piece", "https://i.imgur.com/4x8Zq8s.jpg"),
        ("Goku", 5, "Dragon Ball", "https://i.imgur.com/9x7Zq7s.jpg"),
        ("Tanjiro Kamado", 1, "Demon Slayer", "https://i.imgur.com/3x6Zq6s.jpg"),
        ("Saitama", 5, "One Punch Man", "https://i.imgur.com/2x5Zq5s.jpg")
    ]

    print("🌱 Seeding database...")
    for name, rarity, source, url in cards:
        # ON CONFLICT DO NOTHING prevents duplicates if you run this twice
        await db.execute("""
            INSERT INTO cards (name, rarity, anime_source, image_url) 
            VALUES ($1, $2, $3, $4)
        """, name, rarity, source, url)
        
    print("✅ Database populated with starter cards!")

if __name__ == "__main__":
    asyncio.run(seed())
