import asyncio
from database.db import db

async def migrate():
    await db.connect()
    print("⏳ Adding Raid Tokens...")
    
    # Add 'raid_tokens' column to users table, default 0
    await db.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS raid_tokens INT DEFAULT 0;")
    
    print("✅ Database Upgraded: Black Market Open!")

if __name__ == "__main__":
    asyncio.run(migrate())
