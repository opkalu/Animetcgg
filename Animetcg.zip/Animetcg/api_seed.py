import asyncio
import aiohttp
import os
import random
from dotenv import load_dotenv
from database.db import db

load_dotenv()
API_KEY = os.getenv("WAIFU_IM_TOKEN")

# Names to assign to the random images (Since API doesn't always give names)
# You can expand this list!
ANIME_NAMES = [
    "Mysterious Heroine", "Cyber Punk Girl", "Gothic Lolita", 
    "School Council President", "Demon Princess", "Space Pirate",
    "Forest Elf", "Mecha Pilot", "Shrine Maiden", "Vampire Queen",
    "Battle Maid", "Isekai Traveler", "Dragon Tamer", "Time Traveler",
    "Spirit Fox", "Wandering Samurai", "Shadow Assassin"
]

async def fetch_waifus():
    url = "https://api.waifu.im/search"
    
    # We ask for 30 images at once
    params = {
        "many": "true",
        "limit": 30,
        "included_tags": ["waifu", "maid", "uniform"] 
    }
    
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "User-Agent": "AnimeTCG-Bot/1.0"
    }

    async with aiohttp.ClientSession() as session:
        print("📡 Connecting to Waifu.im API...")
        async with session.get(url, headers=headers, params=params) as resp:
            if resp.status != 200:
                print(f"❌ API Error: {resp.status}")
                return []
            data = await resp.json()
            return data.get('images', [])

async def seed():
    await db.connect()
    
    images = await fetch_waifus()
    
    if not images:
        print("⚠️ No images found. Check your API key.")
        return

    print(f"🔥 Found {len(images)} valid images. Wiping old database...")
    await db.execute("DELETE FROM cards") # Reset DB for fresh start

    count = 0
    for img in images:
        # 1. Get the Direct URL (This is what works on Telegram)
        image_url = img['url']
        
        # 2. Generate Stats
        # Waifu.im gives us an ID, so we can use that for unique tracking
        image_id = img['image_id']
        
        # Pick a random name from our list, or use the ID
        name = random.choice(ANIME_NAMES) + f" #{image_id}"
        
        # Random Rarity
        rarity = random.choices([1, 2, 3, 4, 5], weights=[40, 30, 20, 8, 2])[0]
        
        # Extract tags for "Source"
        tags = [t['name'] for t in img.get('tags', [])]
        source = tags[0].title() if tags else "Original Art"

        # 3. Insert into PostgreSQL
        await db.execute("""
            INSERT INTO cards (name, rarity, anime_source, image_url)
            VALUES ($1, $2, $3, $4)
        """, name, rarity, source, image_url)
        
        count += 1

    print(f"✅ Successfully added {count} cards via API!")

if __name__ == "__main__":
    asyncio.run(seed())
