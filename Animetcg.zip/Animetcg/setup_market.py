import asyncio
from database.db import db

async def init_market():
    await db.connect()
    
    print("🏦 Building the Market...")
    
    # Create the table
    await db.execute("""
        CREATE TABLE IF NOT EXISTS market (
            market_id SERIAL PRIMARY KEY,
            seller_id BIGINT NOT NULL,
            seller_name TEXT,
            card_id INTEGER NOT NULL,
            price INTEGER NOT NULL,
            listed_at TIMESTAMP DEFAULT NOW()
        );
    """)
    
    print("✅ Market Table Created!")
    print("💰 Economy is ready for trading.")

if __name__ == "__main__":
    asyncio.run(init_market())
