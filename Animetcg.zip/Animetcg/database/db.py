import asyncpg
import os
from dotenv import load_dotenv

load_dotenv()

class Database:
    def __init__(self):
        self.pool = None

    async def connect(self):
        if not self.pool:
            try:
                # We use the Environment Variables from .env
                self.pool = await asyncpg.create_pool(
                    user=os.getenv("DB_USER"),
                    password=os.getenv("DB_PASS"),
                    database=os.getenv("DB_NAME"),
                    host=os.getenv("DB_HOST"),
                    min_size=1,
                    max_size=10
                )
                print("✅ Database Connected")
            except Exception as e:
                print(f"❌ Connection Failed: {e}")

    async def execute(self, query, *args):
        # For INSERT, UPDATE, DELETE
        async with self.pool.acquire() as conn:
            return await conn.execute(query, *args)

    async def fetch(self, query, *args):
        # For SELECT (multiple rows)
        async with self.pool.acquire() as conn:
            return await conn.fetch(query, *args)

    async def fetchval(self, query, *args):
        # For SELECT (single value, like COUNT)
        async with self.pool.acquire() as conn:
            return await conn.fetchval(query, *args)

    async def fetchrow(self, query, *args):
        # For SELECT (single row, like one user or card)
        async with self.pool.acquire() as conn:
            return await conn.fetchrow(query, *args)

db = Database()
