import asyncio
from database.db import db

async def migrate():
    await db.connect()
    print("⏳ Creating Bounty System...")
    
    # Simple table: User ID and Total Bounty Amount
    await db.execute("""
        CREATE TABLE IF NOT EXISTS bounties (
            user_id BIGINT PRIMARY KEY,
            amount BIGINT DEFAULT 0
        );
    """)
    
    print("✅ Bounty Board Ready!")

if __name__ == "__main__":
    asyncio.run(migrate())
