import asyncio
from database.db import db

async def migrate():
    await db.connect()
    print("⏳ Updating Cards Table...")
    
    try:
        # Add the 'anime' column
        await db.execute("ALTER TABLE cards ADD COLUMN IF NOT EXISTS anime TEXT DEFAULT 'Unknown';")
        print("✅ Added 'anime' column!")
        
        # Add 'element' column just in case it's missing too
        await db.execute("ALTER TABLE cards ADD COLUMN IF NOT EXISTS element TEXT DEFAULT 'Physical';")
        print("✅ Checked 'element' column!")
        
    except Exception as e:
        print(f"⚠️ Error: {e}")

    print("✅ Database Repair Complete.")

if __name__ == "__main__":
    asyncio.run(migrate())
