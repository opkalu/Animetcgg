import random
import asyncio
import os
import json
from aiogram import Router, types, F
from aiogram.filters import Command
from aiogram.types import FSInputFile
from aiogram.exceptions import TelegramNetworkError
from database.db import db

router = Router()

PULL_COST = 100
ANIMATION_PATH = "assets/animations"
CACHE_FILE = "anim_cache.json"

# Load Animation Cache from Disk (Persistent!)
if os.path.exists(CACHE_FILE):
    with open(CACHE_FILE, "r") as f:
        ANIMATION_CACHE = json.load(f)
else:
    ANIMATION_CACHE = {}

async def save_anim_cache():
    """Saves GIF IDs to disk so they survive restarts."""
    with open(CACHE_FILE, "w") as f:
        json.dump(ANIMATION_CACHE, f)

async def safe_upload(message, file_path, type="photo", caption=""):
    """
    Tries to upload a file 3 times. If internet fails, it retries.
    Returns: The Message object (if success) or None.
    """
    for attempt in range(3):
        try:
            if type == "animation":
                return await message.answer_animation(FSInputFile(file_path), caption=caption)
            else:
                return await message.answer_photo(FSInputFile(file_path), caption=caption)
        except Exception as e:
            print(f"⚠️ Upload Failed (Attempt {attempt+1}/3): {e}")
            await asyncio.sleep(2) # Wait 2s before retry
    return None

@router.message(Command("pull", "summon"))
async def cmd_pull(message: types.Message):
    user_id = message.from_user.id
    
    # 1. Check Funds
    coins = await db.fetchval("SELECT coins FROM users WHERE user_id = $1", user_id)
    if coins < PULL_COST:
        return await message.answer(f"❌ You need {PULL_COST} coins! (Balance: {coins})")

    # 2. DETERMINE RARITY
    roll = random.randint(1, 100)
    if roll <= 2: rarity = 5     # Legendary
    elif roll <= 12: rarity = 4  # Epic
    elif roll <= 40: rarity = 3  # Rare
    elif roll <= 75: rarity = 2  # Common
    else: rarity = 1             # Common

    # 3. 🎬 PLAY ANIMATION (Persistent Cache Mode)
    if rarity == 5:
        gif = "legendary.gif"; wait = 4.0; cap = "🌟 **LEGENDARY...**"
    elif rarity >= 3:
        gif = "epic.gif"; wait = 3.0; cap = "⚡ **Epic...**"
    else:
        gif = "common.gif"; wait = 2.0; cap = "⚪ Summoning..."

    full_anim_path = f"{ANIMATION_PATH}/{gif}"
    if not os.path.exists(full_anim_path): full_anim_path = f"{ANIMATION_PATH}/common.gif"

    animation_msg = None
    
    # CHECK 1: Do we have the ID saved? (Fastest)
    if full_anim_path in ANIMATION_CACHE:
        try:
            # Send using ID (Instant)
            animation_msg = await message.answer_animation(ANIMATION_CACHE[full_anim_path], caption=cap)
            await asyncio.sleep(wait)
        except:
            # ID expired/invalid? Clear it.
            del ANIMATION_CACHE[full_anim_path]
    
    # CHECK 2: If no ID, Upload & Save (Slow, but only happens ONCE)
    if not animation_msg and os.path.exists(full_anim_path):
        animation_msg = await safe_upload(message, full_anim_path, type="animation", caption=cap)
        
        if animation_msg:
            # SAVE ID FOREVER
            ANIMATION_CACHE[full_anim_path] = animation_msg.animation.file_id
            await save_anim_cache() # Write to file
            await asyncio.sleep(wait)
        else:
            # If upload failed 3 times, show text fallback
            animation_msg = await message.answer("🔮 **Summoning...** (Network Weak)")
            await asyncio.sleep(1.0)

    # 4. FETCH CARD
    card = await db.fetchrow("SELECT * FROM cards WHERE rarity = $1 ORDER BY RANDOM() LIMIT 1", rarity)
    if not card: card = await db.fetchrow("SELECT * FROM cards ORDER BY RANDOM() LIMIT 1")

    # 5. DEDUCT & GIVE
    async with db.pool.acquire() as conn:
        async with conn.transaction():
            await conn.execute("UPDATE users SET coins = coins - $1 WHERE user_id = $2", PULL_COST, user_id)
            await conn.execute("INSERT INTO user_cards (user_id, card_id, level, stars, xp) VALUES ($1, $2, 1, $3, 0)", user_id, card['card_id'], card['rarity'])

    # 6. DELETE ANIMATION
    if animation_msg:
        try: await animation_msg.delete()
        except: pass 

    # 7. SEND RESULT (Persistent DB Cache)
    stars = "⭐" * card['rarity']
    count = await db.fetchval("SELECT COUNT(*) FROM user_cards WHERE user_id=$1 AND card_id=$2", user_id, card['card_id'])
    
    txt = (
        f"💫 **SUMMON RESULT**\n"
        f"👤 **{card['name']}**\n"
        f"📺 {card.get('anime', 'Unknown')}\n"
        f"{stars} | {card.get('element', 'Physical')}\n\n"
        f"🎒 Owned: {count}"
    )

    # CHECK 1: Do we have a Cloud ID in Database?
    if card['file_id']:
        try:
            await message.answer_photo(card['file_id'], caption=txt)
            return # Success! Exit function.
        except:
            pass # ID invalid, fall back to upload

    # CHECK 2: Upload from Disk & Save to DB
    path = card['image_url']
    if not path or "http" in path:
        # Just send URL/Text if no local file
        await message.answer_photo(path if path else "https://via.placeholder.com/150", caption=txt)
        return

    # Retry Upload Logic
    msg = await safe_upload(message, path, type="photo", caption=txt)
    
    if msg:
        # SUCCESS! Save the ID to Database immediately
        file_id = msg.photo[-1].file_id
        await db.execute("UPDATE cards SET file_id = $1 WHERE card_id = $2", file_id, card['card_id'])
        # print(f"✅ Saved Permanent Cache for {card['name']}")
    else:
        # If all retries fail
        await message.answer(txt + "\n\n(⚠️ Image upload failed due to network)")
