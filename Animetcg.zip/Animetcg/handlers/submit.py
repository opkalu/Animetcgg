from aiogram import Router, F, types, Bot
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command
from database.db import db

router = Router()

# Admin ID to send reviews to
ADMIN_ID = 7225409964
SUBMISSION_COST = 50

@router.message(Command("submit"))
async def cmd_submit_help(message: types.Message):
    await message.answer(
        f"📤 **Submit a Card** (Cost: {SUBMISSION_COST} coins)\n\n"
        "📜 **Rules:**\n"
        "1. High quality images only.\n"
        "2. No duplicates.\n\n"
        "💰 **Rewards:**\n"
        "• Approved: +150 coins\n"
        "• Denied: No refund.\n\n"
        "<b>Format:</b> Send photo with caption:\n"
        "<code>Name | Rarity | Source</code>",
        parse_mode="HTML"
    )

@router.message(F.photo & F.caption)
async def handle_submission(message: types.Message, bot: Bot):
    user_id = message.from_user.id
    username = message.from_user.username or "Anon"
    caption = message.caption

    # 1. PARSE DATA
    if "|" in caption:
        parts = caption.split("|")
    elif "\n" in caption:
        parts = caption.split("\n")
    elif "," in caption:
        parts = caption.split(",")
    else:
        # If it's just a random photo with no format, ignore it (or send help)
        return await message.answer("⚠️ **Format Invalid!**\nUse: `Name | Rarity | Source`")

    if len(parts) != 3:
        return await message.answer("⚠️ **Missing Info!**\nI need Name, Rarity, and Source.")

    # 2. CHECK BALANCE
    user_coins = await db.fetchval("SELECT coins FROM users WHERE user_id = $1", user_id)
    if user_coins < SUBMISSION_COST:
        return await message.answer(f"❌ You need {SUBMISSION_COST} coins to submit.")

    # Deduct Fee
    await db.execute("UPDATE users SET coins = coins - $1 WHERE user_id = $2", SUBMISSION_COST, user_id)

    try:
        name = parts[0].strip()
        rarity = int(parts[1].strip())
        source = parts[2].strip()
        file_id = message.photo[-1].file_id

        # 3. SEND TO ADMIN
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ Approve", callback_data=f"app_{user_id}_{rarity}"),
                InlineKeyboardButton(text="❌ Deny", callback_data=f"deny_{user_id}")
            ]
        ])

        admin_text = (
            f"📩 **SUBMISSION** (Fee Paid)\n"
            f"👤 User: @{username} (ID: {user_id})\n"
            f"----------------\n"
            f"<b>{name}</b>\n"
            f"Rarity: {rarity}\n"
            f"Source: {source}"
        )
        
        await bot.send_photo(chat_id=ADMIN_ID, photo=file_id, caption=admin_text, reply_markup=keyboard, parse_mode="HTML")
        await message.answer("✅ **Submitted!** Waiting for admin review.")

    except ValueError:
        # Refund on error
        await db.execute("UPDATE users SET coins = coins + $1 WHERE user_id = $2", SUBMISSION_COST, user_id)
        await message.answer("❌ Rarity must be a number (1-5).")
