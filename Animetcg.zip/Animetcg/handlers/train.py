import random
from aiogram import Router, types, F
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from aiogram.exceptions import TelegramBadRequest
from database.db import db

router = Router()

BASE_XP = 100
MAX_LEVEL = 20
EVOLVE_COST = 2000
AWAKEN_COST = 5000

# Name : Description
ABILITIES = {
    "🎯 Precision": "Min RNG roll is 20 (Reliable Damage)",
    "🦁 Wild Fury": "RNG range doubled (High Risk, Massive Dmg)",
    "⚔️ Duelist": "+30 Flat Score vs same Element",
    "🛡️ Iron Wall": "Reduces enemy RNG luck",
    "⚡ Crit Master": "Doubles Critical Hit chance (20%)",
    "🩸 Giant Slayer": "+50 Score if enemy has more Stars"
}

# --- 1. TRAIN MENU (List Cards) ---
@router.message(Command("train", "dojo"))
async def cmd_train(message: types.Message):
    await show_train_menu(message.chat.id, message.from_user.id, message, is_command=True)

# Helper function to show the menu
async def show_train_menu(chat_id, user_id, message_obj, is_command=False):
    cards = await db.fetch("""
        SELECT uc.id, c.name, COALESCE(uc.stars, c.rarity) as stars, uc.level, uc.ability
        FROM user_cards uc
        JOIN cards c ON uc.card_id = c.card_id
        WHERE uc.user_id = $1
        ORDER BY stars DESC, uc.level DESC
        LIMIT 5
    """, user_id)

    if not cards:
        txt = "❌ You have no cards to train. Use /pull first!"
        if is_command: await message_obj.answer(txt)
        else: await message_obj.answer(txt, show_alert=True)
        return

    txt = "🥋 **TRAINING & AWAKENING** 🥋\n"
    txt += "🔮 **Awaken:** Unlock Passive Skills (Requires 3⭐+)\n"
    txt += "🧬 **Evolve:** Rank Up (Requires Lvl 20)\n\n"
    txt += "👇 **Select a fighter:**"

    rows = []
    for c in cards:
        lvl = c['level'] if c['level'] else 1
        star_txt = "⭐" * c['stars']
        ability_icon = "🔮" if c['ability'] else ""
        
        btn_text = f"Lv.{lvl} {c['name']} {star_txt} {ability_icon}"
        rows.append([InlineKeyboardButton(text=btn_text, callback_data=f"train_select_{c['id']}")])

    kb = InlineKeyboardMarkup(inline_keyboard=rows)

    if is_command:
        await message_obj.answer(txt, reply_markup=kb)
    else:
        try:
            if isinstance(message_obj, types.Message):
                await message_obj.edit_text(txt, reply_markup=kb)
            elif isinstance(message_obj, types.CallbackQuery):
                await message_obj.message.edit_text(txt, reply_markup=kb)
        except TelegramBadRequest:
            pass


# --- 2. HANDLE BACK BUTTON ---
@router.callback_query(F.data == "train_menu_back")
async def handle_back(callback: CallbackQuery):
    await show_train_menu(callback.message.chat.id, callback.from_user.id, callback.message, is_command=False)


# --- 3. SHOW CARD DETAILS (Shared Logic) ---
async def render_card_view(message, uc_id):
    """
    Shared function to fetch card data and edit the message.
    Used by: Selection, Train, Awaken, Evolve.
    """
    card = await db.fetchrow("""
        SELECT uc.level, uc.xp, COALESCE(uc.stars, c.rarity) as stars, c.name, uc.ability
        FROM user_cards uc JOIN cards c ON uc.card_id = c.card_id 
        WHERE uc.id = $1
    """, uc_id)
    
    if not card: 
        try: await message.edit_text("❌ Card not found.")
        except: pass
        return

    lvl = card['level'] if card['level'] else 1
    stars = card['stars']
    ability = card['ability']
    xp = card['xp'] if card['xp'] else 0
    xp_needed = lvl * 100

    txt = f"🥋 **TRAINING: {card['name']}**\n"
    txt += f"⭐ Rank: {stars} | Lv: {lvl}/{MAX_LEVEL}\n"
    txt += f"📊 XP: {xp}/{xp_needed}\n"
    
    kb_rows = []

    # A. EVOLUTION
    if lvl >= MAX_LEVEL:
        if stars < 5:
            txt += f"\n🧬 **Evolution Ready!** (Cost: {EVOLVE_COST}c)"
            kb_rows.append([InlineKeyboardButton(text=f"🧬 EVOLVE ({EVOLVE_COST}c)", callback_data=f"evolve_{uc_id}")])
        else:
            txt += "\n🌟 **Max Rank Reached!**"
    
    # B. AWAKENING
    if stars >= 3:
        if ability:
            desc = ABILITIES.get(ability, "Unknown Power")
            txt += f"\n🔮 **Ability:** {ability}\nℹ️ {desc}\n"
            kb_rows.append([InlineKeyboardButton(text=f"🎲 Reroll Skill ({AWAKEN_COST}c)", callback_data=f"awaken_{uc_id}")])
        else:
            txt += "\n🔮 **No Ability:** Can be Awakened."
            kb_rows.append([InlineKeyboardButton(text=f"🔮 AWAKEN SKILL ({AWAKEN_COST}c)", callback_data=f"awaken_{uc_id}")])
    else:
        txt += "\n🔒 **Awakening Locked:** Needs 3⭐+"

    # Training Button
    cost = lvl * 100
    if lvl < MAX_LEVEL:
        kb_rows.append([InlineKeyboardButton(text=f"👊 Train (+XP) 💰{cost}", callback_data=f"do_train_{uc_id}")])

    kb_rows.append([InlineKeyboardButton(text="🔙 Back", callback_data="train_menu_back")])

    try:
        await message.edit_text(txt, reply_markup=InlineKeyboardMarkup(inline_keyboard=kb_rows))
    except TelegramBadRequest:
        pass 


# --- 4. SELECT CARD ---
@router.callback_query(F.data.startswith("train_select_"))
async def handle_card_view(callback: CallbackQuery):
    uc_id = int(callback.data.split("_")[2])
    await render_card_view(callback.message, uc_id)


# --- 5. EXECUTE TRAINING (XP) ---
@router.callback_query(F.data.startswith("do_train_"))
async def do_train_xp(callback: CallbackQuery):
    uc_id = int(callback.data.split("_")[2])
    user_id = callback.from_user.id
    
    card = await db.fetchrow("SELECT uc.level, uc.xp FROM user_cards uc WHERE uc.id=$1", uc_id)
    lvl, xp = (card['level'] or 1), (card['xp'] or 0)
    
    cost = lvl * 100
    coins = await db.fetchval("SELECT coins FROM users WHERE user_id=$1", user_id)
    
    if coins < cost: return await callback.answer(f"❌ Need {cost} coins!", show_alert=True)
    if lvl >= MAX_LEVEL: return await callback.answer("Max Level Reached!", show_alert=True)

    # XP Logic
    is_crit = random.randint(1, 10) == 1
    xp_gain = BASE_XP * 2 if is_crit else BASE_XP

    # Guild Buff
    guild_buff = await db.fetchval("""
        SELECT g.buff_xp FROM guilds g
        JOIN guild_members gm ON g.guild_id = gm.guild_id
        WHERE gm.user_id = $1
    """, user_id)
    
    buff_msg = ""
    if guild_buff and guild_buff > 0:
        bonus = int(xp_gain * (guild_buff * 0.05))
        xp_gain += bonus
        buff_msg = " (🏛️ Boosted)"

    # Calc new stats
    new_xp = xp + xp_gain
    new_lvl = lvl
    
    needed = new_lvl * 100
    leveled_up = False
    
    while new_xp >= needed and new_lvl < MAX_LEVEL:
        new_xp -= needed
        new_lvl += 1
        needed = new_lvl * 100
        leveled_up = True

    async with db.pool.acquire() as conn:
        async with conn.transaction():
            await conn.execute("UPDATE users SET coins=coins-$1 WHERE user_id=$2", cost, user_id)
            await conn.execute("UPDATE user_cards SET level=$1, xp=$2 WHERE id=$3", new_lvl, new_xp, uc_id)

    # Update UI by calling shared function
    await render_card_view(callback.message, uc_id)
    
    msg = f"+{xp_gain} XP"
    if is_crit: msg += " (CRIT!)"
    if leveled_up: msg += "\n🎉 LEVEL UP!"
    msg += buff_msg
    
    await callback.answer(msg)


# --- 6. EXECUTE AWAKENING/REROLL ---
@router.callback_query(F.data.startswith("awaken_"))
async def handle_awakening(callback: CallbackQuery):
    uc_id = int(callback.data.split("_")[1])
    user_id = callback.from_user.id

    coins = await db.fetchval("SELECT coins FROM users WHERE user_id=$1", user_id)
    if coins < AWAKEN_COST: return await callback.answer(f"❌ Need {AWAKEN_COST} coins!", show_alert=True)

    new_ability = random.choice(list(ABILITIES.keys()))

    async with db.pool.acquire() as conn:
        async with conn.transaction():
            await conn.execute("UPDATE users SET coins=coins-$1 WHERE user_id=$2", AWAKEN_COST, user_id)
            await conn.execute("UPDATE user_cards SET ability=$1 WHERE id=$2", new_ability, uc_id)

    # Update UI
    await render_card_view(callback.message, uc_id)
    
    desc = ABILITIES[new_ability]
    await callback.answer(f"🔮 UNLOCKED: {new_ability}!\n{desc}", show_alert=True)


# --- 7. EXECUTE EVOLUTION ---
@router.callback_query(F.data.startswith("evolve_"))
async def execute_evolve(callback: CallbackQuery):
    uc_id = int(callback.data.split("_")[1])
    user_id = callback.from_user.id
    
    coins = await db.fetchval("SELECT coins FROM users WHERE user_id=$1", user_id)
    if coins < EVOLVE_COST: return await callback.answer("❌ Too poor!", show_alert=True)

    card = await db.fetchrow("SELECT COALESCE(uc.stars, c.rarity) as stars FROM user_cards uc JOIN cards c ON uc.card_id=c.card_id WHERE uc.id=$1", uc_id)
    
    async with db.pool.acquire() as conn:
        async with conn.transaction():
            await conn.execute("UPDATE users SET coins=coins-$1 WHERE user_id=$2", EVOLVE_COST, user_id)
            await conn.execute("UPDATE user_cards SET level=1, xp=0, stars=$1 WHERE id=$2", card['stars']+1, uc_id)

    # Update UI
    await render_card_view(callback.message, uc_id)
    
    await callback.answer("🧬 EVOLUTION COMPLETE!", show_alert=True)
