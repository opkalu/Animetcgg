from aiogram import Router, F, types, Bot
from aiogram.types import CallbackQuery
from aiogram.filters import Command
from database.db import db

router = Router()

ADMIN_ID = 7225409964  # Replace with your ID

# --- 1. GOD MODE: GIVE COINS ---
@router.message(Command("give"))
async def cmd_give_coins(message: types.Message, bot: Bot):
    if message.from_user.id != ADMIN_ID: return
    args = message.text.split()
    if len(args) != 3: return await message.answer("Usage: /give ID AMOUNT")
    try:
        target_id = int(args[1])
        amount = int(args[2])
        await db.execute("UPDATE users SET coins = coins + $1 WHERE user_id = $2", amount, target_id)
        await message.answer(f"✅ Sent {amount} coins to {target_id}.")
        await bot.send_message(target_id, f"💰 **Admin Gift:** {amount} coins received!")
    except: await message.answer("❌ Error.")

# --- 2. DIRECT ADMIN UPLOAD (With Elements) ---
# Format: Name | Rarity | Source | Element
@router.message(F.photo & F.caption & (F.from_user.id == ADMIN_ID))
async def admin_direct_upload(message: types.Message):
    try:
        caption = message.caption
        if "|" in caption: parts = caption.split("|")
        elif "\n" in caption: parts = caption.split("\n")
        else: return await message.answer("❌ Format: `Name | Rarity | Source | Element`")

        if len(parts) < 3: return await message.answer("❌ Missing info.")

        name = parts[0].strip()
        rarity = int(parts[1].strip())
        source = parts[2].strip()
        
        # Check if Element is provided, otherwise default to Neutral
        if len(parts) == 4:
            element = parts[3].strip().title() # Capitalize (fire -> Fire)
        else:
            element = "Neutral"

        valid_elements = ["Fire", "Water", "Leaf", "Neutral"]
        if element not in valid_elements:
             return await message.answer("❌ Element must be: Fire, Water, Leaf, or Neutral")

        file_id = message.photo[-1].file_id

        await db.execute("""
            INSERT INTO cards (name, rarity, anime_source, image_url, element)
            VALUES ($1, $2, $3, $4, $5)
        """, name, rarity, source, file_id, element)

        await message.reply(f"✅ **Saved:** {name}\n🔥 Element: {element}")

    except ValueError:
        await message.answer("❌ Rarity must be a number.")
    except Exception as e:
        await message.answer(f"❌ Error: {e}")

# --- 3. SUBMISSION APPROVALS ---
@router.callback_query(F.data.startswith("app_"))
async def approve_submission(callback: CallbackQuery, bot: Bot):
    data = callback.data.split("_")
    user_id = int(data[1])
    
    try:
        text = callback.message.caption
        lines = text.split("\n")
        name = lines[3].strip()
        rarity = int([l for l in lines if "Rarity:" in l][0].split(":")[1].strip())
        source = [l for l in lines if "Source:" in l][0].split(":")[1].strip()
        file_id = callback.message.photo[-1].file_id
        
        # Submissions currently default to Neutral unless we upgrade submit.py too
        element = "Neutral" 

        await db.execute("""
            INSERT INTO cards (name, rarity, anime_source, image_url, element)
            VALUES ($1, $2, $3, $4, $5)
        """, name, rarity, source, file_id, element)

        REWARD = 150
        await db.execute("UPDATE users SET coins = coins + $1 WHERE user_id = $2", REWARD, user_id)
        await bot.send_message(user_id, f"🎉 **Approved:** {name}\n💰 +{REWARD} coins!")
        await callback.message.edit_caption(caption=f"✅ **APPROVED:** {name}")

    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)

@router.callback_query(F.data.startswith("deny_"))
async def deny_submission(callback: CallbackQuery, bot: Bot):
    user_id = int(callback.data.split("_")[1])
    await callback.message.delete()
    try: await bot.send_message(user_id, "❌ **Denied.**")
    except: pass
