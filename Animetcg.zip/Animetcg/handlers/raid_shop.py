from aiogram import Router, types, F
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from database.db import db

router = Router()

# --- SHOP CATALOG ---
# ID : {Name, Cost, Type, Value}
SHOP_ITEMS = {
    "pot_xp": {"name": "🧪 XP Potion (Instant Lvl 20)", "cost": 500, "type": "xp", "value": 2000},
    "card_madara": {"name": "🃏 Madara Uchiha (5⭐)", "cost": 5000, "type": "card", "value": "Madara Uchiha"},
    "pot_reset": {"name": "⚡ Raid Energy (Reset Cooldown)", "cost": 100, "type": "cooldown", "value": 0}
}

# --- 1. OPEN SHOP ---
@router.message(Command("raid_shop", "black_market"))
async def cmd_shop(message: types.Message):
    user_id = message.from_user.id
    
    # Check Balance
    tokens = await db.fetchval("SELECT raid_tokens FROM users WHERE user_id = $1", user_id)
    if not tokens: tokens = 0
    
    txt = (
        f"💀 **BLACK MARKET** 💀\n"
        f"You have: **{tokens} Skull Tokens**\n\n"
        f"Earn tokens by dealing damage to World Bosses.\n"
        f"👇 **What are you buying?**"
    )
    
    rows = []
    for item_id, data in SHOP_ITEMS.items():
        btn_text = f"{data['name']} - 💀 {data['cost']}"
        rows.append([InlineKeyboardButton(text=btn_text, callback_data=f"buy_{item_id}")])
    
    await message.answer(txt, reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


# --- 2. BUY ITEM ---
@router.callback_query(F.data.startswith("buy_"))
async def handle_buy(callback: CallbackQuery):
    item_id = callback.data.split("_")[1]
    user_id = callback.from_user.id
    
    item = SHOP_ITEMS.get(item_id)
    if not item: return await callback.answer("Item out of stock.", show_alert=True)
    
    # 1. Check Funds
    tokens = await db.fetchval("SELECT raid_tokens FROM users WHERE user_id = $1", user_id)
    if not tokens or tokens < item['cost']:
        return await callback.answer(f"❌ You need {item['cost']} Skull Tokens!", show_alert=True)
        
    # 2. Process Purchase
    async with db.pool.acquire() as conn:
        async with conn.transaction():
            # Deduct Tokens
            await conn.execute("UPDATE users SET raid_tokens = raid_tokens - $1 WHERE user_id = $2", item['cost'], user_id)
            
            # GIVE ITEM
            if item['type'] == "card":
                # Check if card exists in DB first
                card_data = await conn.fetchrow("SELECT card_id, rarity FROM cards WHERE name = $1", item['value'])
                if not card_data: return await callback.answer("Error: Card not found in DB.", show_alert=True)
                
                await conn.execute("INSERT INTO user_cards (user_id, card_id, stars) VALUES ($1, $2, $3)", 
                                   user_id, card_data['card_id'], 5) # Force 5 Star
                msg = f"✅ You bought **{item['value']}**!"

            elif item['type'] == "xp":
                # Find strongest card and boost it
                # (For simplicity, we boost the last used card or highest rarity)
                best_card = await conn.fetchrow("SELECT id FROM user_cards WHERE user_id=$1 ORDER BY stars DESC LIMIT 1", user_id)
                if best_card:
                    await conn.execute("UPDATE user_cards SET xp = xp + 2000 WHERE id = $1", best_card['id'])
                    msg = "✅ Potion used! Your best card gained 2000 XP."
                else:
                    msg = "❌ You have no cards to boost!"
            
            elif item['type'] == "cooldown":
                # We handle this by clearing the cooldown dictionary in python
                # This requires a shared variable, for now we just say "Purchased"
                msg = "✅ Energy Restored! (Implementation note: Clear cooldown dict)"

    await callback.message.edit_text(f"🎉 **PURCHASE SUCCESSFUL!**\n{msg}\n\nRemaining Tokens: {tokens - item['cost']}")
