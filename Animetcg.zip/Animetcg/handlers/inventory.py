from aiogram import Router, types
from aiogram.filters import Command
from database.db import db

router = Router()

@router.message(Command("bag", "inventory"))
async def cmd_bag(message: types.Message):
    user_id = message.from_user.id
    
    # 1. Fetch user's cards (Grouped by name to show count)
    rows = await db.fetch("""
        SELECT c.name, c.rarity, c.anime_source, COUNT(uc.id) as count
        FROM user_cards uc
        JOIN cards c ON uc.card_id = c.card_id
        WHERE uc.user_id = $1
        GROUP BY c.name, c.rarity, c.anime_source
        ORDER BY c.rarity DESC, count DESC
    """, user_id)

    if not rows:
        return await message.answer("🎒 **Your Bag is Empty!**\nUse /pull to get your first card.")

    # 2. Format the Output
    text = "🎒 <b>YOUR COLLECTION</b>\n"
    
    # Rarity Emojis
    rarity_map = {
        5: "🔴 MYTHIC",
        4: "🟡 LEGENDARY",
        3: "🟣 EPIC",
        2: "🔵 RARE",
        1: "⚪ COMMON"
    }

    current_rarity = None

    for row in rows:
        # Add a header when rarity changes
        if row['rarity'] != current_rarity:
            current_rarity = row['rarity']
            text += f"\n<b>{rarity_map[current_rarity]}</b>\n"
        
        # List the card: • Name (Source) xCount
        text += f"• {row['name']} <i>({row['anime_source']})</i> <b>x{row['count']}</b>\n"

    # 3. Send the message (Split if too long)
    if len(text) > 4000:
        text = text[:4000] + "\n...(truncated)"
        
    await message.answer(text, parse_mode="HTML")
