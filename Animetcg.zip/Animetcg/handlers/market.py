from aiogram import Router, types, Bot
from aiogram.filters import Command
from database.db import db

router = Router()

TAX_RATE = 0.05 # 5% Tax

# --- 1. SELL CARD (No changes here, just context) ---
@router.message(Command("sell"))
async def cmd_sell(message: types.Message):
    args = message.text.split()
    if len(args) < 3: return await message.answer("💰 **Usage:** `/sell [Name] [Price]`")
    
    try: price = int(args[-1])
    except: return await message.answer("❌ Price must be a number.")
    
    if price < 10: return await message.answer("❌ Min price: 10 coins.")
    
    card_name = " ".join(args[1:-1])
    user_id = message.from_user.id
    
    card = await db.fetchrow("""
        SELECT uc.id, c.card_id, c.name, c.rarity FROM user_cards uc
        JOIN cards c ON uc.card_id = c.card_id
        WHERE uc.user_id = $1 AND c.name ILIKE $2 LIMIT 1
    """, user_id, card_name)
    
    if not card: return await message.answer(f"❌ You don't have **{card_name}**!")
    
    async with db.pool.acquire() as conn:
        async with conn.transaction():
            await conn.execute("DELETE FROM user_cards WHERE id = $1", card['id'])
            await conn.execute("INSERT INTO market (seller_id, card_id, price) VALUES ($1, $2, $3)", user_id, card['card_id'], price)
            
    await message.answer(f"✅ **Listed:** {card['name']} for {price} coins.")


# --- 2. VIEW MARKET (Updated with SEARCH) ---
@router.message(Command("market", "shop"))
async def cmd_market(message: types.Message):
    args = message.text.split(maxsplit=1)
    
    # If user types "/market Dragon", we search for "Dragon"
    search_query = args[1] if len(args) > 1 else None
    
    if search_query:
        # SEARCH MODE
        listings = await db.fetch("""
            SELECT m.market_id, m.price, c.name, c.rarity, u.username
            FROM market m
            JOIN cards c ON m.card_id = c.card_id
            JOIN users u ON m.seller_id = u.user_id
            WHERE c.name ILIKE $1
            ORDER BY m.price ASC LIMIT 10
        """, f"%{search_query}%")
        title = f"🔍 **SEARCH RESULTS: {search_query}**"
    else:
        # DEFAULT MODE (Latest 10)
        listings = await db.fetch("""
            SELECT m.market_id, m.price, c.name, c.rarity, u.username
            FROM market m
            JOIN cards c ON m.card_id = c.card_id
            JOIN users u ON m.seller_id = u.user_id
            ORDER BY m.listed_at DESC LIMIT 10
        """)
        title = "🏪 **GLOBAL MARKET (Newest)**"

    if not listings:
        return await message.answer("❌ No items found.")

    txt = f"{title}\n\n"
    for item in listings:
        txt += f"🆔 **{item['market_id']}** | {item['name']} ({item['rarity']}⭐)\n"
        txt += f"💰 {item['price']} | 👤 {item['username']}\n"
        txt += f"------------------------\n"
    
    txt += "\n🛒 **Buy:** `/buy [ID]`\n🔍 **Search:** `/market [Name]`"
    await message.answer(txt)


# --- 3. BUY CARD (No changes) ---
@router.message(Command("buy"))
async def cmd_buy(message: types.Message, bot: Bot):
    args = message.text.split()
    if len(args) != 2: return await message.answer("🛒 Usage: `/buy [ID]`")
    try: mid = int(args[1])
    except: return await message.answer("❌ ID must be a number.")
    
    buyer_id = message.from_user.id
    listing = await db.fetchrow("""
        SELECT m.*, c.name FROM market m JOIN cards c ON m.card_id = c.card_id WHERE market_id = $1
    """, mid)
    
    if not listing: return await message.answer("❌ Item sold or invalid.")
    if listing['seller_id'] == buyer_id: return await message.answer("❌ You can't buy your own item! Use `/retrieve`.")
    
    cost = listing['price']
    coins = await db.fetchval("SELECT coins FROM users WHERE user_id = $1", buyer_id)
    if coins < cost: return await message.answer(f"❌ Need {cost} coins.")
    
    tax = int(cost * TAX_RATE)
    profit = cost - tax
    
    async with db.pool.acquire() as conn:
        async with conn.transaction():
            await conn.execute("UPDATE users SET coins = coins - $1 WHERE user_id = $2", cost, buyer_id)
            await conn.execute("UPDATE users SET coins = coins + $1 WHERE user_id = $2", profit, listing['seller_id'])
            await conn.execute("INSERT INTO user_cards (user_id, card_id) VALUES ($1, $2)", buyer_id, listing['card_id'])
            await conn.execute("DELETE FROM market WHERE market_id = $1", mid)
            
    await message.answer(f"🎉 Bought **{listing['name']}** for {cost} coins!")
    try:
        await bot.send_message(listing['seller_id'], f"💰 **SOLD:** {listing['name']}\nProfit: {profit} coins (+{tax} tax)")
    except: pass


# --- 4. MY LISTINGS (New Feature) ---
@router.message(Command("my_listings", "selling"))
async def cmd_my_listings(message: types.Message):
    user_id = message.from_user.id
    
    listings = await db.fetch("""
        SELECT m.market_id, m.price, c.name, c.rarity
        FROM market m
        JOIN cards c ON m.card_id = c.card_id
        WHERE m.seller_id = $1
    """, user_id)
    
    if not listings: return await message.answer("You are not selling anything.")
    
    txt = "🎒 **YOUR ACTIVE LISTINGS**\n\n"
    for item in listings:
        txt += f"🆔 **{item['market_id']}** | {item['name']} - {item['price']}c\n"
        
    txt += "\n↩️ **Retrieve:** `/retrieve [ID]`"
    await message.answer(txt)


# --- 5. RETRIEVE ITEM (New Feature) ---
@router.message(Command("retrieve", "cancel_sell"))
async def cmd_retrieve(message: types.Message):
    args = message.text.split()
    if len(args) != 2: return await message.answer("Usage: `/retrieve [ID]`")
    
    try: mid = int(args[1])
    except: return await message.answer("❌ ID must be a number.")
    
    user_id = message.from_user.id
    
    # Check if this listing belongs to the user
    listing = await db.fetchrow("SELECT card_id FROM market WHERE market_id = $1 AND seller_id = $2", mid, user_id)
    
    if not listing:
        return await message.answer("❌ This is not your listing!")
        
    # Execute Retrieval
    async with db.pool.acquire() as conn:
        async with conn.transaction():
            # Delete from Market
            await conn.execute("DELETE FROM market WHERE market_id = $1", mid)
            # Give back to User
            await conn.execute("INSERT INTO user_cards (user_id, card_id) VALUES ($1, $2)", user_id, listing['card_id'])
            
    await message.answer("✅ **Item Retrieved!** The card is back in your inventory.")
