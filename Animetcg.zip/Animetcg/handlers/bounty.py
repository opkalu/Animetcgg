from aiogram import Router, types
from aiogram.filters import Command
from database.db import db

router = Router()

# --- 1. SET BOUNTY ---
@router.message(Command("set_bounty", "bounty"))
async def cmd_set_bounty(message: types.Message):
    # Usage: /set_bounty @User [Amount]
    args = message.text.split()
    
    if len(args) != 3:
        return await message.answer("💀 **Usage:** `/set_bounty @User [Amount]`")

    target_name = args[1].replace("@", "")
    try:
        amount = int(args[2])
    except:
        return await message.answer("❌ Amount must be a number.")

    if amount < 100:
        return await message.answer("❌ Minimum bounty is 100 coins.")

    setter = message.from_user

    # 1. FIND TARGET
    target = await db.fetchrow("SELECT user_id FROM users WHERE username ILIKE $1", target_name)
    if not target:
        return await message.answer("❌ User not found.")
    
    target_id = target['user_id']
    if target_id == setter.id:
        return await message.answer("❌ You cannot put a bounty on yourself (weirdo).")

    # 2. CHECK FUNDS
    balance = await db.fetchval("SELECT coins FROM users WHERE user_id = $1", setter.id)
    if balance < amount:
        return await message.answer(f"❌ You only have {balance} coins.")

    # 3. TRANSACTION
    async with db.pool.acquire() as conn:
        async with conn.transaction():
            # Take money from setter
            await conn.execute("UPDATE users SET coins = coins - $1 WHERE user_id = $2", amount, setter.id)
            
            # Add to bounty table (Upsert: Update if exists, Insert if not)
            await conn.execute("""
                INSERT INTO bounties (user_id, amount) VALUES ($1, $2)
                ON CONFLICT (user_id) DO UPDATE 
                SET amount = bounties.amount + $2
            """, target_id, amount)

    # 4. ANNOUNCE
    await message.answer(
        f"🚨 **BOUNTY SET!** 🚨\n\n"
        f"🎯 **Target:** @{target_name}\n"
        f"💰 **Price:** {amount} coins\n"
        f"🕵️ **Setter:** {setter.first_name}\n\n"
        f"⚔️ Defeat them in a `/duel` to claim the reward!"
    )


# --- 2. WANTED LIST ---
@router.message(Command("wanted", "bounties"))
async def cmd_wanted(message: types.Message):
    rows = await db.fetch("""
        SELECT u.username, b.amount 
        FROM bounties b
        JOIN users u ON b.user_id = u.user_id
        ORDER BY b.amount DESC LIMIT 10
    """)

    if not rows:
        return await message.answer("☮️ **Peaceful Times.** No active bounties.")

    txt = "📜 **MOST WANTED LIST** 📜\n\n"
    for i, r in enumerate(rows, 1):
        txt += f"{i}. **@{r['username']}** — 💰 {r['amount']}\n"

    await message.answer(txt)
