import random
import asyncio
from aiogram import Router, F, types, Bot
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from database.db import db

router = Router()

# STORE ACTIVE DUELS IN MEMORY
# Key: f"{p1_id}_{p2_id}"
active_duels = {}

# --- 1. SEND CHALLENGE ---
@router.message(Command("duel", "fight"))
async def cmd_duel(message: types.Message, bot: Bot):
    # Usage: /duel @username [amount]
    args = message.text.split()
    
    if len(args) != 3:
        return await message.answer("⚔️ **Usage:** `/duel @username [amount]`")

    target_username = args[1].replace("@", "")
    
    try:
        wager = int(args[2])
    except ValueError:
        return await message.answer("❌ Wager must be a number.")

    if wager < 10:
        return await message.answer("❌ Minimum bet is 10 coins.")

    challenger = message.from_user

    if target_username.lower() == challenger.username.lower():
        return await message.answer("❌ You cannot fight yourself.")

    # 1. FIND TARGET IN DB
    target = await db.fetchrow("SELECT user_id, username, coins FROM users WHERE username ILIKE $1", target_username)

    if not target:
        return await message.answer(f"❌ User @{target_username} is not registered.")

    target_id = target['user_id']
    target_coins = target['coins']
    challenger_coins = await db.fetchval("SELECT coins FROM users WHERE user_id = $1", challenger.id)

    # 2. CHECK BALANCES
    if challenger_coins < wager:
        return await message.answer(f"❌ You are too poor! You need {wager} coins.")
    if target_coins < wager:
        return await message.answer(f"❌ @{target_username} is too poor (Needs {wager}).")

    # 3. SEND CHALLENGE DM
    duel_id = f"{challenger.id}_{target_id}"
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text=f"⚔️ ACCEPT ({wager}c)", callback_data=f"d_acc_{duel_id}_{wager}"),
            InlineKeyboardButton(text="❌ REJECT", callback_data=f"d_rej_{duel_id}")
        ]
    ])

    try:
        await bot.send_message(
            chat_id=target_id,
            text=(
                f"⚔️ **INCOMING CHALLENGE!**\n\n"
                f"👤 **{challenger.first_name}** wants to duel!\n"
                f"💰 **Stakes:** {wager} Coins\n\n"
                f"Do you accept?"
            ),
            reply_markup=keyboard
        )
        await message.answer(f"✅ Challenge sent to **@{target_username}**!")
    except:
        await message.answer(f"❌ Could not DM @{target_username}. They need to start the bot first.")


# --- 2. ACCEPT & SHOW CARD MENU ---
@router.callback_query(F.data.startswith("d_acc_"))
async def accept_duel(callback: CallbackQuery, bot: Bot):
    # Data: d_acc_CHALLENGER_TARGET_WAGER
    parts = callback.data.split("_")
    c_id = int(parts[2])
    t_id = int(parts[3])
    wager = int(parts[4])

    duel_key = f"{c_id}_{t_id}"
    
    # Initialize Duel State
    active_duels[duel_key] = {
        "amount": wager,
        "p1": c_id,
        "p2": t_id,
        "p1_card": None,
        "p2_card": None
    }

    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer("✅ **Accepted!** Check your DMs to pick your fighter.")

    # Function to send card menu
    async def send_card_menu(user_id, opponent_name):
        # Fetch Top 5 Strongest Cards (Stars DESC, Level DESC)
        cards = await db.fetch("""
            SELECT uc.id, c.name, COALESCE(uc.stars, c.rarity) as stars, c.element, uc.level, uc.ability
            FROM user_cards uc
            JOIN cards c ON uc.card_id = c.card_id
            WHERE uc.user_id = $1
            ORDER BY stars DESC, uc.level DESC, c.name ASC
            LIMIT 5
        """, user_id)

        if not cards:
            return 

        kb_rows = []
        for c in cards:
            icon = "🔥" if c['element'] == "Fire" else "💧" if c['element'] == "Water" else "🍃" if c['element'] == "Leaf" else "⚪"
            ability_icon = "🔮" if c['ability'] else ""
            
            # Button: Lv.20 Dragon (5⭐) 🔥 🔮
            btn_text = f"Lv.{c['level']} {c['name']} ({c['stars']}⭐) {icon} {ability_icon}"
            
            cb_data = f"pick_{duel_key}_{user_id}_{c['id']}"
            kb_rows.append([InlineKeyboardButton(text=btn_text, callback_data=cb_data)])

        await bot.send_message(
            chat_id=user_id,
            text=f"🆚 Fighting **{opponent_name}**\n💰 Pot: {wager*2}\n\n**Choose your Fighter:**",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=kb_rows)
        )

    p1_name = await db.fetchval("SELECT username FROM users WHERE user_id = $1", c_id)
    p2_name = await db.fetchval("SELECT username FROM users WHERE user_id = $1", t_id)

    await send_card_menu(c_id, p2_name)
    await send_card_menu(t_id, p1_name)


# --- 3. HANDLE CARD SELECTION ---
@router.callback_query(F.data.startswith("pick_"))
async def pick_fighter(callback: CallbackQuery, bot: Bot):
    parts = callback.data.split("_")
    duel_key = f"{parts[1]}_{parts[2]}" 
    user_id = int(parts[3])
    uc_id = int(parts[4])

    if duel_key not in active_duels:
        return await callback.answer("❌ Duel expired.", show_alert=True)

    duel = active_duels[duel_key]

    card_name = await db.fetchval("""
        SELECT c.name FROM user_cards uc 
        JOIN cards c ON uc.card_id = c.card_id 
        WHERE uc.id = $1
    """, uc_id)

    if user_id == duel['p1']:
        duel['p1_card'] = uc_id
    else:
        duel['p2_card'] = uc_id

    await callback.message.edit_text(f"✅ Selected: **{card_name}**\nWaiting for opponent...")

    if duel['p1_card'] and duel['p2_card']:
        await execute_fight(duel, bot)
        del active_duels[duel_key]


# --- 4. EXECUTE FIGHT (ABILITIES + EVOLUTION) ---
async def execute_fight(duel, bot: Bot):
    p1, p2, wager = duel['p1'], duel['p2'], duel['amount']
    
    # 1. FETCH FULL DATA (Stats + Stars + Ability)
    async def get_fighter_data(uc_id):
        return await db.fetchrow("""
            SELECT uc.id, uc.level, uc.xp, COALESCE(uc.stars, c.rarity) as stars, c.name, c.element, c.image_url, uc.ability
            FROM user_cards uc
            JOIN cards c ON uc.card_id = c.card_id
            WHERE uc.id = $1
        """, uc_id)

    c1 = await get_fighter_data(duel['p1_card'])
    c2 = await get_fighter_data(duel['p2_card'])

    # --- SCORE CALCULATION LOGIC ---
    def calculate_power(card, opponent):
        # Base Stats
        score = (card['stars'] * 25) + (card['level'] * 5)
        log_entry = ""
        
        # RNG Settings
        rng_min, rng_max = 1, 40
        crit_chance = 10 # 10%
        
        # --- ABILITY MODIFIERS ---
        ability = card['ability']
        
        if ability == "🎯 Precision":
            rng_min = 20 # Guaranteed minimum damage
            log_entry += "🎯 **Precision:** Min roll 20!\n"
            
        elif ability == "🦁 Wild Fury":
            rng_max = 80 # Massive potential
            log_entry += "🦁 **Wild Fury:** RNG 1-80!\n"
            
        elif ability == "⚔️ Duelist":
            if card['element'] == opponent['element']:
                score += 30
                log_entry += "⚔️ **Duelist:** +30 vs same element!\n"
                
        elif ability == "⚡ Crit Master":
            crit_chance = 25 # 25% chance
            log_entry += "⚡ **Crit Master:** Crit chance UP!\n"
            
        elif ability == "🩸 Giant Slayer":
            if opponent['stars'] > card['stars']:
                score += 50
                log_entry += "🩸 **Giant Slayer:** +50 vs Higher Rank!\n"
        
        elif ability == "🛡️ Iron Wall":
            score += 20
            log_entry += "🛡️ **Iron Wall:** +20 Defense!\n"

        # Apply RNG
        roll = random.randint(rng_min, rng_max)
        score += roll
        
        # Check Crit
        is_crit = random.randint(1, 100) <= crit_chance
        if is_crit:
            score += 40
            log_entry += f"💥 **CRIT!** (+40) [Roll: {roll}]\n"
        else:
            log_entry += f"🎲 Roll: {roll}\n"

        return score, log_entry

    # Calculate for both sides
    s1, log1 = calculate_power(c1, c2)
    s2, log2 = calculate_power(c2, c1)
    
    battle_log = f"🔵 **{c1['name']}** ({c1['stars']}⭐)\n{log1}\n"
    battle_log += f"🔴 **{c2['name']}** ({c2['stars']}⭐)\n{log2}\n"

    # --- ELEMENTAL ADVANTAGE ---
    e1, e2 = c1['element'], c2['element']
    BONUS = 30
    if (e1=="Fire" and e2=="Leaf") or (e1=="Leaf" and e2=="Water") or (e1=="Water" and e2=="Fire"):
        s1 += BONUS
        battle_log += f"🔥 **Type Advantage!** {c1['name']} +{BONUS}\n"
    elif (e2=="Fire" and e1=="Leaf") or (e2=="Leaf" and e1=="Water") or (e2=="Water" and e1=="Fire"):
        s2 += BONUS
        battle_log += f"🌊 **Type Advantage!** {c2['name']} +{BONUS}\n"

    # --- PET BONUS (Dragon) ---
    async def check_pet(uid, score, name):
        pet = await db.fetchrow("SELECT pet_type, hunger, nickname FROM pets WHERE user_id = $1", uid)
        if pet and pet['pet_type'] == "Dragon" and pet['hunger'] > 20:
            await db.execute("UPDATE pets SET hunger = hunger - 5 WHERE user_id = $1", uid)
            return score + 20, f"🐉 **{pet['nickname']}** helped! (+20)\n"
        return score, ""

    s1, p1_log = await check_pet(p1, s1, c1['name'])
    s2, p2_log = await check_pet(p2, s2, c2['name'])
    battle_log += p1_log + p2_log

    # --- DETERMINE WINNER ---
    if s1 > s2:
        winner_id, loser_id = p1, p2
        w_card, l_card = c1, c2
        w_score, l_score = s1, s2
        win_img = c1['image_url']
    elif s2 > s1:
        winner_id, loser_id = p2, p1
        w_card, l_card = c2, c1
        w_score, l_score = s2, s1
        win_img = c2['image_url']
    else:
        msg = f"🤝 **DRAW!**\n{s1} vs {s2}\nNo coins lost."
        await bot.send_message(p1, msg); await bot.send_message(p2, msg)
        return

    # --- XP & LEVEL UP ---
    async def give_xp(card, xp_amount):
        new_xp = card['xp'] + xp_amount
        current_lvl = card['level']
        req_xp = current_lvl * 100
        
        leveled_up = False
        new_lvl = current_lvl

        if new_xp >= req_xp:
            new_lvl += 1
            new_xp -= req_xp
            leveled_up = True
            
        await db.execute("UPDATE user_cards SET level=$1, xp=$2 WHERE id=$3", new_lvl, new_xp, card['id'])
        return leveled_up

    w_up = await give_xp(w_card, 50)
    l_up = await give_xp(l_card, 10)

    xp_log = f"\n✨ **XP:** {w_card['name']} +50" + (" (LVL UP!)" if w_up else "")
    xp_log += f", {l_card['name']} +10" + (" (LVL UP!)" if l_up else "")

    # --- BOUNTY SYSTEM ---
    bounty_bonus = 0
    bounty_data = await db.fetchrow("SELECT amount FROM bounties WHERE user_id = $1", loser_id)
    if bounty_data:
        bounty_bonus = bounty_data['amount']
        await db.execute("DELETE FROM bounties WHERE user_id = $1", loser_id)

    # --- TRANSACTION ---
    total_win = wager + bounty_bonus
    await db.execute("UPDATE users SET coins = coins + $1, wins = wins + 1 WHERE user_id = $2", total_win, winner_id)
    await db.execute("UPDATE users SET coins = coins - $1, losses = losses + 1 WHERE user_id = $2", wager, loser_id)

    # --- FINAL MESSAGE ---
    winner_row = await db.fetchrow("SELECT username, wins FROM users WHERE user_id = $1", winner_id)
    winner_name = f"@{winner_row['username']}"
    
    bounty_text = f"\n💀 **BOUNTY CLAIMED:** +{bounty_bonus} coins!" if bounty_bonus > 0 else ""

    caption = (
        f"⚔️ **DUEL RESULT** ⚔️\n\n"
        f"🏆 **WINNER:** {winner_name}\n"
        f"💰 **Won:** {wager * 2} Coins{bounty_text}\n"
        f"------------------\n"
        f"💥 **{w_score}** vs **{l_score}**\n"
        f"{xp_log}\n\n"
        f"📜 **Combat Log:**\n"
        f"<i>{battle_log}</i>"
    )

    try:
        await bot.send_photo(chat_id=p1, photo=win_img, caption=caption, parse_mode="HTML")
        await bot.send_photo(chat_id=p2, photo=win_img, caption=caption, parse_mode="HTML")
    except:
        await bot.send_message(p1, caption)
        await bot.send_message(p2, caption)

@router.callback_query(F.data.startswith("d_rej_"))
async def reject_duel(callback: CallbackQuery):
    await callback.message.edit_text("❌ **Duel Rejected.**")
