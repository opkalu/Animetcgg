from aiogram import Router, types
from aiogram.filters import Command

router = Router()

@router.message(Command("help"))
async def cmd_help(message: types.Message):
    txt = (
        "📖 **PLAYER COMMANDS GUIDE** 📖\n\n"
        
        "🟢 **STARTER**\n"
        "• `/start` - Register & Main Menu\n"
        "• `/daily` - Claim free coins 💰\n"
        "• `/profile` - View your stats\n"
        "• `/codes` - Redeem promo codes\n\n"
        
        "🃏 **CARDS & TRAINING**\n"
        "• `/pull` - Summon new cards (100c)\n"
        "• `/bag` - View your card inventory\n"
        "• `/train` - Level up & Awaken cards 🥋\n"
        "• `/fuse` - Merge duplicates for XP\n\n"
        
        "⚔️ **COMBAT & RAIDS**\n"
        "• `/raid` - Fight World Bosses (Infinite Rotation) 👹\n"
        "• `/raid_shop` - Spend Skull Tokens 💀\n"
        "• `/duel @user` - Challenge a player\n"
        "• `/leaderboard` - Top Players\n\n"
        
        "🏰 **SOCIAL & ECONOMY**\n"
        "• `/guild` - Create or Join a Clan\n"
        "• `/market` - Buy/Sell cards with players\n"
        "• `/pet` - Manage your pet companion\n\n"
        
        "💡 *Tip: Use /train often to get stronger for Raids!*"
    )
    
    await message.answer(txt, parse_mode="Markdown")
