from aiogram import Router, types
from aiogram.filters import Command
from database.db import db

router = Router()

# CONFIG
PET_PRICES = {
    "slime": 5000,   # Bonus: +20% Daily Coins
    "dragon": 10000, # Bonus: +10% Battle Damage
    "golem": 8000    # Bonus: 10% Chance to block damage (Not implemented yet)
}
FOOD_COST = 200 # Restores 20 Hunger

# --- 1. ADOPT A PET ---
@router.message(Command("adopt", "buy_pet"))
async def cmd_adopt(message: types.Message):
    # Usage: /adopt slime
    args = message.text.split()
    
    if len(args) != 2:
        txt = "🐾 **PET SHOP** 🐾\n\n"
        txt += "🟢 **Slime** (5,000c): +20% Coins from /daily\n"
        txt += "🔴 **Dragon** (10,000c): +10% Damage in Battles\n\n"
        txt += "Usage: `/adopt [type]` (e.g., `/adopt dragon`)"
        return await message.answer(txt)

    pet_type = args[1].lower()
    if pet_type not in PET_PRICES:
        return await message.answer("❌ Unknown pet type. Choose: Slime, Dragon.")

    cost = PET_PRICES[pet_type]
    user_id = message.from_user.id

    # Check if already has pet
    if await db.fetchval("SELECT 1 FROM pets WHERE user_id = $1", user_id):
        return await message.answer("❌ You already have a pet! Use `/release_pet` first (You will lose it).")

    # Check Funds
    balance = await db.fetchval("SELECT coins FROM users WHERE user_id = $1", user_id)
    if balance < cost:
        return await message.answer(f"❌ You need {cost} coins.")

    # Transaction
    async with db.pool.acquire() as conn:
        async with conn.transaction():
            await conn.execute("UPDATE users SET coins = coins - $1 WHERE user_id = $2", cost, user_id)
            await conn.execute("INSERT INTO pets (user_id, pet_type) VALUES ($1, $2)", user_id, pet_type.capitalize())

    await message.answer(f"🎉 **You adopted a {pet_type.capitalize()}!**\nName it using `/name_pet [Name]`.")


# --- 2. CHECK PET ---
@router.message(Command("pet", "mypet"))
async def cmd_check_pet(message: types.Message):
    user_id = message.from_user.id
    pet = await db.fetchrow("SELECT * FROM pets WHERE user_id = $1", user_id)

    if not pet:
        return await message.answer("❌ You don't have a pet. Type `/adopt` to get one!")

    # Hunger Bar [■■■■■□□□□□]
    hunger = pet['hunger']
    bars = int(hunger / 10)
    bar_str = "🍖" * bars + "⚪" * (10 - bars)
    
    status = "Happy 😄" if hunger > 50 else "Hungry 😟" if hunger > 20 else "Starving 😵 (Bonuses Disabled)"

    buff_text = ""
    if pet['pet_type'] == "Slime": buff_text = "💰 **Buff:** +20% Daily Coins"
    elif pet['pet_type'] == "Dragon": buff_text = "⚔️ **Buff:** +10% Damage"

    await message.answer(
        f"🐾 **{pet['nickname']}** (The {pet['pet_type']})\n\n"
        f"{buff_text}\n"
        f"🍔 **Hunger:** {hunger}%\n"
        f"{bar_str}\n"
        f"Status: {status}\n\n"
        f"Type `/feed` to give food (Costs {FOOD_COST}c)."
    )


# --- 3. FEED PET ---
@router.message(Command("feed"))
async def cmd_feed(message: types.Message):
    user_id = message.from_user.id
    pet = await db.fetchrow("SELECT hunger FROM pets WHERE user_id = $1", user_id)

    if not pet: return await message.answer("❌ You have no pet.")
    
    if pet['hunger'] >= 100:
        return await message.answer("❌ Your pet is full!")

    # Check Money
    coins = await db.fetchval("SELECT coins FROM users WHERE user_id = $1", user_id)
    if coins < FOOD_COST:
        return await message.answer(f"❌ You need {FOOD_COST} coins to buy food.")

    # Feed Logic (Restore 20 hunger, cap at 100)
    new_hunger = min(100, pet['hunger'] + 20)
    
    async with db.pool.acquire() as conn:
        async with conn.transaction():
            await conn.execute("UPDATE users SET coins = coins - $1 WHERE user_id = $2", FOOD_COST, user_id)
            await conn.execute("UPDATE pets SET hunger = $1 WHERE user_id = $2", new_hunger, user_id)

    await message.answer(f"🍖 **Yummy!** Pet hunger restored to {new_hunger}%.")


# --- 4. RENAME PET ---
@router.message(Command("name_pet"))
async def cmd_rename(message: types.Message):
    args = message.text.split(maxsplit=1)
    if len(args) != 2: return await message.answer("Usage: `/name_pet [Name]`")
    
    name = args[1].strip()[:15] # Limit length
    user_id = message.from_user.id
    
    if not await db.fetchval("SELECT 1 FROM pets WHERE user_id = $1", user_id):
        return await message.answer("❌ You have no pet.")

    await db.execute("UPDATE pets SET nickname = $1 WHERE user_id = $2", name, user_id)
    await message.answer(f"✅ Your pet is now named **{name}**!")
