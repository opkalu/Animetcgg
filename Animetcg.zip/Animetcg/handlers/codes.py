from aiogram import Router, types
from aiogram.filters import Command
from database.db import db

router = Router()

ADMIN_ID = 7225409964

# --- 1. ADMIN: CREATE CODE ---
@router.message(Command("create_code", "add_code"))
async def cmd_create_code(message: types.Message):
    # Security: Only you
    if message.from_user.id != ADMIN_ID:
        return

    # Usage: /create_code [CODE] [REWARD] [MAX_USERS]
    # Example: /create_code WELCOME 500 100
    args = message.text.split()
    
    if len(args) != 4:
        return await message.answer(
            "🛠️ **Usage:** `/create_code [Name] [Coins] [Uses]`\n"
            "Example: `/create_code LAUNCH 1000 50`"
        )

    code_name = args[1].upper()
    try:
        reward = int(args[2])
        uses = int(args[3])
    except ValueError:
        return await message.answer("❌ Reward and Uses must be numbers.")

    # Save to DB
    try:
        await db.execute("""
            INSERT INTO promo_codes (code, reward, uses_left)
            VALUES ($1, $2, $3)
            ON CONFLICT (code) DO UPDATE 
            SET reward = $2, uses_left = $3
        """, code_name, reward, uses)
        
        await message.answer(
            f"✅ **Code Created!**\n\n"
            f"🔑 Code: `{code_name}`\n"
            f"💰 Value: {reward} Coins\n"
            f"👥 Claims: {uses} users\n\n"
            f"Share it now!"
        )
    except Exception as e:
        await message.answer(f"❌ Error: {e}")


# --- 2. USER: REDEEM CODE ---
@router.message(Command("redeem", "code"))
async def cmd_redeem(message: types.Message):
    # Usage: /redeem [CODE]
    args = message.text.split()
    
    if len(args) != 2:
        return await message.answer("🎁 **Usage:** `/redeem [CODE]`")

    code_input = args[1].upper()
    user_id = message.from_user.id

    # 1. CHECK IF CODE EXISTS & HAS USES
    code_data = await db.fetchrow("""
        SELECT reward, uses_left FROM promo_codes 
        WHERE code = $1
    """, code_input)

    if not code_data:
        return await message.answer("❌ Invalid or expired code.")

    reward = code_data['reward']
    uses_left = code_data['uses_left']

    if uses_left <= 0:
        return await message.answer("❌ This code has been fully claimed! (0 uses left)")

    # 2. CHECK IF USER ALREADY CLAIMED
    already_claimed = await db.fetchval("""
        SELECT 1 FROM redeemed_codes 
        WHERE user_id = $1 AND code = $2
    """, user_id, code_input)

    if already_claimed:
        return await message.answer("❌ You already claimed this code!")

    # 3. CLAIM TRANSACTION
    # We use a transaction to ensure no "double spend" glitch
    async with db.pool.acquire() as conn:
        async with conn.transaction():
            # Deduct use
            await conn.execute("UPDATE promo_codes SET uses_left = uses_left - 1 WHERE code = $1", code_input)
            
            # Record claim
            await conn.execute("INSERT INTO redeemed_codes (user_id, code) VALUES ($1, $2)", user_id, code_input)
            
            # Give coins
            await conn.execute("UPDATE users SET coins = coins + $1 WHERE user_id = $2", reward, user_id)

    await message.answer(
        f"🎉 **CODE REDEEMED!**\n\n"
        f"🔑 Code: `{code_input}`\n"
        f"💰 You received **{reward} Coins**!"
    )
