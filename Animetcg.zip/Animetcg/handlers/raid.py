import random
import asyncio
import time
import os
from aiogram import Router, types, F
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery, FSInputFile
from aiogram.exceptions import TelegramBadRequest
from database.db import db

router = Router()

COOLDOWN = 1.5 
user_cooldowns = {}

# --- 👹 BOSS DEFINITIONS ---
BOSS_POOL = [
    {
        "name": "Madara Uchiha",
        "element": "Fire",
        "base_hp": 50000,
        "image_url": "https://media1.tenor.com/m/7y2j5vG3aowAAAAC/madara-uchiha-fire.gif"
    },
    {
        "name": "Kaido",
        "element": "Water",
        "base_hp": 80000, 
        "image_url": "https://media1.tenor.com/m/Yk4t1k_uQcMAAAAC/kaido-dragon-breath.gif"
    },
    {
        "name": "Sosuke Aizen",
        "element": "Leaf",
        "base_hp": 40000, 
        "image_url": "https://media1.tenor.com/m/m1C1vTQAeS4AAAAC/aizen-sosuke-bleach.gif"
    }
]

# --- HELPER: Boss Text ---
def get_raid_text(boss):
    hp, max_hp = boss['hp'], boss['max_hp']
    name, lvl, element = boss['name'], boss['level'], boss['element']
    
    percent = int((hp / max_hp) * 10)
    percent = max(0, min(10, percent))
    bar = "🟩" * percent + "🟥" * (10 - percent)
    
    mechanic = ""
    if name == "Madara Uchiha": mechanic = "🔥 **Passive:** Susanoo Armor (<50% HP)"
    elif name == "Kaido": mechanic = "🛡️ **Passive:** Dragon Scales (Max Dmg Cap: 2000)"
    elif name == "Sosuke Aizen": mechanic = "🌀 **Passive:** Kyoka Suigetsu (40% Dodge)"

    return (
        f"👹 **RAID BOSS (Lvl {lvl})**\n"
        f"💀 **{name}** [{element}]\n"
        f"{mechanic}\n\n"
        f"❤️ **HP:** {hp:,} / {max_hp:,}\n"
        f"[{bar}]\n\n"
        f"⚔️ **Join the Fight!**"
    )

# --- 1. SPAWN SYSTEM ---
async def spawn_new_boss(current_level):
    new_level = current_level + 1
    boss_data = random.choice(BOSS_POOL)
    
    # Scale HP: Base * (1 + (Level * 0.2))
    scaled_hp = int(boss_data['base_hp'] * (1 + (new_level * 0.2)))
    
    await db.execute("""
        UPDATE raid_boss 
        SET name=$1, element=$2, hp=$3, max_hp=$3, image_url=$4, is_active=TRUE, level=$5, boss_type=$1
    """, boss_data['name'], boss_data['element'], scaled_hp, boss_data['image_url'], new_level)
    
    return boss_data['name'], new_level

# --- 2. VIEW BOSS ---
@router.message(Command("raid", "boss"))
async def cmd_raid(message: types.Message):
    boss = await db.fetchrow("SELECT * FROM raid_boss LIMIT 1")
    
    if not boss or not boss['is_active']:
        current_lvl = boss['level'] if boss else 0
        name, lvl = await spawn_new_boss(current_lvl)
        return await message.answer(f"⚠️ **A NEW THREAT HAS AWAKENED!**\n\n👹 **{name} (Level {lvl})** is here!")

    txt = get_raid_text(boss)
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"⚔️ ATTACK ({boss['element']})", callback_data="raid_attack")],
        [InlineKeyboardButton(text="🏆 Leaderboard", callback_data="raid_rank")]
    ])

    # Asset Loader
    base_path = f"assets/boss/{boss['name']}"
    file_to_send = None
    if os.path.exists(base_path + ".gif"): file_to_send = FSInputFile(base_path + ".gif"); is_anim=True
    elif os.path.exists(base_path + ".png"): file_to_send = FSInputFile(base_path + ".png"); is_anim=False

    try:
        if file_to_send:
            if is_anim: await message.answer_animation(file_to_send, caption=txt, reply_markup=kb)
            else: await message.answer_photo(file_to_send, caption=txt, reply_markup=kb)
        else:
            if boss['image_url'] and "http" in boss['image_url']:
                 await message.answer_animation(boss['image_url'], caption=txt, reply_markup=kb)
            else:
                await message.answer(txt, reply_markup=kb)
    except Exception as e:
        await message.answer(txt, reply_markup=kb)


# --- 3. SMART ATTACK LOGIC (With Guild Buffs) ---
@router.callback_query(F.data == "raid_attack")
async def handle_attack(callback: CallbackQuery):
    user_id = callback.from_user.id
    
    # Cooldown
    current_time = time.time()
    if user_id in user_cooldowns:
        elapsed = current_time - user_cooldowns[user_id]
        if elapsed < COOLDOWN: return await callback.answer(f"⏳ Wait {int(COOLDOWN - elapsed)}s!", show_alert=True)
    user_cooldowns[user_id] = current_time

    # Fetch Data
    best_card = await db.fetchrow("""
        SELECT uc.level, COALESCE(uc.stars, c.rarity) as stars, c.element, uc.ability
        FROM user_cards uc JOIN cards c ON uc.card_id = c.card_id
        WHERE uc.user_id = $1 ORDER BY stars DESC, level DESC LIMIT 1
    """, user_id)
    
    boss = await db.fetchrow("SELECT * FROM raid_boss WHERE is_active = TRUE LIMIT 1")
    if not boss: return await callback.answer("Boss is dead!", show_alert=True)

    # --- DAMAGE FORMULA ---
    raw_damage = (best_card['stars'] * 25) + (best_card['level'] * 5)
    final_damage = raw_damage
    log_msg = ""

    # A. GUILD BUFF CHECK (Armory)
    guild_buff = await db.fetchval("""
        SELECT g.buff_dmg FROM guilds g
        JOIN guild_members gm ON g.guild_id = gm.guild_id
        WHERE gm.user_id = $1
    """, user_id)

    if guild_buff and guild_buff > 0:
        # 2% Damage per level
        bonus_pct = guild_buff * 0.02
        bonus_dmg = int(final_damage * bonus_pct)
        final_damage += bonus_dmg
        # log_msg += f"⚔️ Guild Buff (+{bonus_dmg})\n" # Optional: Show in log

    # B. ELEMENTAL LOGIC
    p_el, b_el = best_card['element'], boss['element']
    weakness_map = {"Fire": "Water", "Water": "Leaf", "Leaf": "Fire"}
    
    if weakness_map.get(b_el) == p_el:
        final_damage *= 2.0; log_msg = "⚡ SUPER EFFECTIVE! (2x)"
    elif weakness_map.get(p_el) == b_el:
        final_damage *= 0.5; log_msg = "😓 RESISTED... (0.5x)"

    # C. UNIQUE BOSS MECHANICS
    boss_name = boss['name']
    hp_pct = (boss['hp'] / boss['max_hp']) * 100

    if boss_name == "Sosuke Aizen":
        if best_card['ability'] != "🎯 Precision" and random.randint(1, 100) <= 40:
            return await callback.answer("🌀 Aizen used Illusion! (Missed)", show_alert=True)
    
    elif boss_name == "Kaido":
        if final_damage > 2000:
            final_damage = 2000
            log_msg = "🛡️ Dragon Scales (Dmg Capped)"

    elif boss_name == "Madara Uchiha" and hp_pct <= 50:
        final_damage *= 0.5
        log_msg = "🛡️ Susanoo Block (0.5x)"

    # D. CRIT
    if random.randint(1, 10) == 1: 
        final_damage *= 1.5; log_msg += " (CRIT!)"

    final_damage = int(final_damage)

    # --- REWARDS ---
    token_multiplier = 1 + (boss['level'] * 0.1)
    tokens_earned = int((final_damage / 100) * token_multiplier)
    if tokens_earned < 1: tokens_earned = 1

    # --- DB UPDATE ---
    new_hp = boss['hp'] - final_damage
    
    async with db.pool.acquire() as conn:
        async with conn.transaction():
            await conn.execute("UPDATE raid_boss SET hp = $1 WHERE id = $2", new_hp, boss['id'])
            
            exists = await conn.fetchval("SELECT 1 FROM raid_logs WHERE user_id = $1", user_id)
            if exists: await conn.execute("UPDATE raid_logs SET damage = damage + $1 WHERE user_id = $2", final_damage, user_id)
            else: await conn.execute("INSERT INTO raid_logs (user_id, damage) VALUES ($1, $2)", user_id, final_damage)

            await conn.execute("UPDATE users SET raid_tokens = raid_tokens + $1 WHERE user_id = $2", tokens_earned, user_id)

    # --- UI UPDATE ---
    if new_hp <= 0:
        await kill_boss(callback.message, boss)
    else:
        popup = f"💥 {final_damage} Dmg!"
        if tokens_earned > 0: popup += f"\n💀 +{tokens_earned} Tokens"
        if log_msg: popup += f"\n{log_msg}"
        await callback.answer(popup)
        
        try:
            new_txt = get_raid_text({**boss, 'hp': new_hp})
            await callback.message.edit_caption(caption=new_txt, reply_markup=callback.message.reply_markup)
        except: pass


# --- 4. BOSS DEATH ---
async def kill_boss(message, boss):
    contributors = await db.fetch("SELECT user_id, damage FROM raid_logs ORDER BY damage DESC")
    
    pool = 10000 + (boss['level'] * 5000)
    
    log_txt = f"🏆 **{boss['name']} (Lvl {boss['level']}) DEFEATED!**\n"
    log_txt += f"🎁 **Reward Pool:** {pool:,} coins\n\n"
    
    async with db.pool.acquire() as conn:
        async with conn.transaction():
            total_dmg = sum([c['damage'] for c in contributors])
            if total_dmg == 0: total_dmg = 1

            for i, p in enumerate(contributors):
                share = p['damage'] / total_dmg
                reward = int(pool * share)
                
                if i == 0: reward += 5000; icon="🥇"
                elif i == 1: reward += 2000; icon="🥈"
                else: icon="🎖️"

                await conn.execute("UPDATE users SET coins = coins + $1 WHERE user_id = $2", reward, p['user_id'])
                if i < 5: 
                    u = await conn.fetchval("SELECT username FROM users WHERE user_id=$1", p['user_id'])
                    u_name = u if u else f"Hunter {p['user_id']}"
                    log_txt += f"{icon} **{u_name}**: {reward}c\n"

            await conn.execute("DELETE FROM raid_logs")
            await conn.execute("UPDATE raid_boss SET is_active = FALSE")

    await message.answer(log_txt)
    await message.answer("⚠️ **The next boss is approaching...**\nType /raid to summon them!")

@router.callback_query(F.data == "raid_rank")
async def raid_rank(callback: CallbackQuery):
    rankings = await db.fetch("SELECT u.username, r.damage FROM raid_logs r JOIN users u ON r.user_id=u.user_id ORDER BY r.damage DESC LIMIT 10")
    if not rankings: return await callback.answer("No damage yet.", show_alert=True)
    txt = "📊 **LEADERBOARD**\n\n"
    for i, r in enumerate(rankings):
        name = r['username'] if r['username'] else "Unknown"
        txt += f"{i+1}. {name} - {r['damage']}\n"
    await callback.answer(txt, show_alert=True)
