import random
import datetime
from aiogram import Router, types
from aiogram.filters import Command
from database.db import db

router = Router()

@router.message(Command("daily"))
async def cmd_daily(message: types.Message):
    user_id = message.from_user.id
    
    # 1. CHECK COOLDOWN
    last_daily = await db.fetchval("SELECT last_daily FROM users WHERE user_id = $1", user_id)
    
    if last_daily:
        # Calculate time difference
        now = datetime.datetime.now()
        diff = now - last_daily
        if diff.total_seconds() < 86400: # 24 hours
            # Calculate remaining time
            remaining = 86400 - diff.total_seconds()
            hours = int(remaining // 3600)
            minutes = int((remaining % 3600) // 60)
            return await message.answer(f"⏳ **Come back later!**\nWait {hours}h {minutes}m.")

    # 2. CALCULATE BASE REWARD
    amount = random.randint(100, 300)
    bonus_text = ""

    # 3. CHECK PET BONUS (Slime)
    # We fetch the pet's type and hunger
    pet = await db.fetchrow("SELECT pet_type, hunger, nickname FROM pets WHERE user_id = $1", user_id)
    
    if pet and pet['pet_type'] == "Slime":
        if pet['hunger'] > 20:
            # Apply Bonus
            bonus = int(amount * 0.20) # 20%
            amount += bonus
            bonus_text = f"\n🐌 **{pet['nickname']} Bonus:** +{bonus} coins"
            
            # Decrease Hunger (Pet worked hard!)
            await db.execute("UPDATE pets SET hunger = hunger - 10 WHERE user_id = $1", user_id)
        else:
            bonus_text = f"\n🐌 **{pet['nickname']}** is too hungry to help..."

    # 4. UPDATE DATABASE
    # Update coins and reset daily timer
    await db.execute("UPDATE users SET coins = coins + $1, last_daily = NOW() WHERE user_id = $2", amount, user_id)
    
    await message.answer(f"☀️ **Daily Reward Claimed!**\n💰 You received **{amount} coins**!{bonus_text}")
