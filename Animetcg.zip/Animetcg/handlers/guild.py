from aiogram import Router, types, F
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from database.db import db

router = Router()

CREATE_COST = 10000
BUFF_COST_BASE = 5000

# --- 1. MAIN GUILD MENU ---
@router.message(Command("guild", "clan"))
async def cmd_guild(message: types.Message):
    user_id = message.from_user.id
    
    # Check if user is in a guild
    member = await db.fetchrow("SELECT * FROM guild_members WHERE user_id = $1", user_id)
    
    if not member:
        return await message.answer(
            "🏚️ **You are homeless.**\n\n"
            "Join a guild to get passive buffs and protection!\n"
            f"Or create one for 💰 {CREATE_COST} coins.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🆕 Create Guild", callback_data="guild_create")],
                [InlineKeyboardButton(text="🔍 Browse Guilds", callback_data="guild_browse")]
            ])
        )

    # Show Guild Dashboard
    guild = await db.fetchrow("SELECT * FROM guilds WHERE guild_id = $1", member['guild_id'])
    
    if not guild:
        # Error handling if guild was deleted but member still exists
        await db.execute("DELETE FROM guild_members WHERE user_id = $1", user_id)
        return await message.answer("❌ Your guild no longer exists.")

    # Buff Stats
    xp_boost = guild.get('buff_xp', 0) * 5  # 5% per level
    dmg_boost = guild.get('buff_dmg', 0) * 2 # 2% per level
    
    txt = (
        f"🏰 **{guild['name']}** (Lvl {guild.get('level', 1)})\n"
        f"👑 Leader ID: {guild['leader_id']}\n"
        f"💰 Treasury: {guild.get('funds', 0):,} coins\n\n"
        f"⚡ **Active Tech:**\n"
        f"📚 Academy: Lvl {guild.get('buff_xp', 0)} (+{xp_boost}% XP)\n"
        f"⚔️ Armory: Lvl {guild.get('buff_dmg', 0)} (+{dmg_boost}% Dmg)\n\n"
        f"👇 **Member Actions:**"
    )
    
    rows = [
        [InlineKeyboardButton(text="💸 Donate 1000c", callback_data="guild_donate_1000")],
        [InlineKeyboardButton(text="🚪 Leave Guild", callback_data="guild_leave")]
    ]
    
    # Leader Only Actions
    if member.get('role') == 'Leader':
        rows.insert(0, [InlineKeyboardButton(text="🛠️ Upgrade Tech", callback_data="guild_tech")])

    await message.answer(txt, reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


# --- 2. BROWSE & JOIN (The Missing Part) ---
@router.callback_query(F.data == "guild_browse")
async def handle_browse(callback: CallbackQuery):
    # Get top 10 guilds by level/funds
    guilds = await db.fetch("SELECT guild_id, name, level, funds FROM guilds ORDER BY level DESC, funds DESC LIMIT 10")
    
    if not guilds:
        return await callback.answer("No guilds found. Create one!", show_alert=True)
        
    txt = "🔍 **GUILD RECRUITMENT**\nClick a guild to join instantly!\n\n"
    rows = []
    
    for g in guilds:
        btn_text = f"Lvl {g.get('level', 1)} | {g['name']}"
        rows.append([InlineKeyboardButton(text=btn_text, callback_data=f"guild_join_{g['guild_id']}")])
        
    rows.append([InlineKeyboardButton(text="🔙 Back", callback_data="guild_menu_back")]) # Just re-runs /guild logic if implemented or user can type command
    
    await callback.message.edit_text(txt, reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))

@router.callback_query(F.data.startswith("guild_join_"))
async def handle_join(callback: CallbackQuery):
    guild_id = int(callback.data.split("_")[2])
    user_id = callback.from_user.id
    
    # Double check if user is already in guild
    exists = await db.fetchval("SELECT 1 FROM guild_members WHERE user_id=$1", user_id)
    if exists: return await callback.answer("❌ You are already in a guild!", show_alert=True)
    
    # Insert Member
    await db.execute("INSERT INTO guild_members (user_id, guild_id, role) VALUES ($1, $2, 'Member')", user_id, guild_id)
    
    await callback.message.delete()
    await callback.message.answer(f"✅ **You have joined the guild!**\nType /guild to see your new home.")


# --- 3. LEAVE GUILD (The Other Missing Part) ---
@router.callback_query(F.data == "guild_leave")
async def handle_leave(callback: CallbackQuery):
    user_id = callback.from_user.id
    
    member = await db.fetchrow("SELECT role, guild_id FROM guild_members WHERE user_id=$1", user_id)
    if not member: return await callback.answer("You aren't in a guild.", show_alert=True)
    
    if member['role'] == 'Leader':
        return await callback.answer("❌ LEADERS CANNOT LEAVE.\nYou must disband the guild or transfer ownership.", show_alert=True)
        
    await db.execute("DELETE FROM guild_members WHERE user_id=$1", user_id)
    await callback.message.edit_text("👋 You left the guild.")


# --- 4. CREATE GUILD ---
@router.callback_query(F.data == "guild_create")
async def handle_create_info(callback: CallbackQuery):
    await callback.message.answer("📝 **To create a guild:**\nType `/create_guild [Name]`\nExample: `/create_guild Akatsuki`")
    await callback.answer()

@router.message(Command("create_guild"))
async def cmd_create_guild(message: types.Message):
    user_id = message.from_user.id
    args = message.text.split(maxsplit=1)
    
    if len(args) < 2: return await message.answer("❌ Usage: `/create_guild Name`")
    name = args[1]
    
    coins = await db.fetchval("SELECT coins FROM users WHERE user_id = $1", user_id)
    if coins < CREATE_COST: return await message.answer(f"❌ Cost: {CREATE_COST} coins")
    
    in_guild = await db.fetchval("SELECT 1 FROM guild_members WHERE user_id = $1", user_id)
    if in_guild: return await message.answer("❌ Leave your current guild first.")

    try:
        async with db.pool.acquire() as conn:
            async with conn.transaction():
                await conn.execute("UPDATE users SET coins = coins - $1 WHERE user_id = $2", CREATE_COST, user_id)
                # Create with defaults
                g_id = await conn.fetchval("""
                    INSERT INTO guilds (name, leader_id, funds, level, buff_xp, buff_dmg) 
                    VALUES ($1, $2, 0, 1, 0, 0) RETURNING guild_id
                """, name, user_id)
                await conn.execute("INSERT INTO guild_members (user_id, guild_id, role) VALUES ($1, $2, 'Leader')", user_id, g_id)
        
        await message.answer(f"🏰 **{name} Established!**\nUse /guild to manage it.")
    except Exception as e:
        await message.answer(f"❌ Error: {e}")


# --- 5. DONATE & TECH ---
@router.callback_query(F.data.startswith("guild_donate_"))
async def handle_donate(callback: CallbackQuery):
    amount = int(callback.data.split("_")[2])
    user_id = callback.from_user.id
    
    member = await db.fetchrow("SELECT guild_id FROM guild_members WHERE user_id=$1", user_id)
    if not member: return
    
    coins = await db.fetchval("SELECT coins FROM users WHERE user_id=$1", user_id)
    if coins < amount: return await callback.answer("❌ Too poor!", show_alert=True)
    
    async with db.pool.acquire() as conn:
        async with conn.transaction():
            await conn.execute("UPDATE users SET coins=coins-$1 WHERE user_id=$2", amount, user_id)
            await conn.execute("UPDATE guilds SET funds=funds+$1 WHERE guild_id=$2", amount, member['guild_id'])
            
    await callback.answer(f"✅ Donated {amount} coins!", show_alert=True)

@router.callback_query(F.data == "guild_tech")
async def handle_tech(callback: CallbackQuery):
    user_id = callback.from_user.id
    member = await db.fetchrow("SELECT guild_id FROM guild_members WHERE user_id=$1 AND role='Leader'", user_id)
    
    if not member: return await callback.answer("❌ Leaders only.", show_alert=True)
    
    guild = await db.fetchrow("SELECT * FROM guilds WHERE guild_id=$1", member['guild_id'])
    
    # Calc Costs
    cost_xp = BUFF_COST_BASE * (guild.get('buff_xp', 0) + 1)
    cost_dmg = BUFF_COST_BASE * (guild.get('buff_dmg', 0) + 1)
    
    txt = (
        f"🛠️ **GUILD TECHNOLOGY**\n"
        f"Treasury: {guild.get('funds', 0):,} coins\n\n"
        f"1️⃣ **Academy (XP)**: Lvl {guild.get('buff_xp', 0)} -> {guild.get('buff_xp', 0)+1}\n"
        f"Cost: {cost_xp}c\n\n"
        f"2️⃣ **Armory (Dmg)**: Lvl {guild.get('buff_dmg', 0)} -> {guild.get('buff_dmg', 0)+1}\n"
        f"Cost: {cost_dmg}c"
    )
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"📚 Upgrade XP ({cost_xp}c)", callback_data="tech_up_xp")],
        [InlineKeyboardButton(text=f"⚔️ Upgrade Dmg ({cost_dmg}c)", callback_data="tech_up_dmg")]
    ])
    await callback.message.edit_text(txt, reply_markup=kb)

@router.callback_query(F.data.startswith("tech_up_"))
async def upgrade_tech(callback: CallbackQuery):
    tech_type = callback.data.split("_")[2] 
    user_id = callback.from_user.id
    
    member = await db.fetchrow("SELECT guild_id FROM guild_members WHERE user_id=$1 AND role='Leader'", user_id)
    if not member: return
    
    guild = await db.fetchrow("SELECT * FROM guilds WHERE guild_id=$1", member['guild_id'])
    
    if tech_type == 'xp':
        cost = BUFF_COST_BASE * (guild.get('buff_xp', 0) + 1)
        col = "buff_xp"
    else:
        cost = BUFF_COST_BASE * (guild.get('buff_dmg', 0) + 1)
        col = "buff_dmg"
        
    if guild.get('funds', 0) < cost:
        return await callback.answer("❌ Guild needs more funds!", show_alert=True)
        
    await db.execute(f"UPDATE guilds SET funds=funds-$1, {col}={col}+1 WHERE guild_id=$2", cost, member['guild_id'])
    await callback.answer("✅ Upgrade Complete!", show_alert=True)
