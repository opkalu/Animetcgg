import asyncio
from aiogram import Router, types, F
from aiogram.filters import Command
from aiogram.types import FSInputFile, InputMediaPhoto
from database.db import db

router = Router()

# Fusion Costs (Coins per rarity)
FUSE_COSTS = {
    1: 500,   # 1⭐ -> 2⭐
    2: 1500,  # 2⭐ -> 3⭐
    3: 5000,  # 3⭐ -> 4⭐
    4: 15000  # 4⭐ -> 5⭐
}

@router.message(Command("fuse", "merge"))
async def cmd_fuse(message: types.Message):
    user_id = message.from_user.id
    args = message.text.split(maxsplit=1)
    
    if len(args) < 2:
        return await message.reply("❌ **Usage:**\n`/fuse [Name]` (e.g., /fuse Slime)\n`/fuse [Number]` (e.g., /fuse 1)")
    
    query = args[1]

    # --- MODE 1: BULK FUSE BY RARITY ---
    if query.isdigit():
        rarity = int(query)
        if rarity < 1 or rarity > 4:
            return await message.reply("❌ Rarity must be between 1 and 4.")
        return await bulk_fuse_rarity(message, user_id, rarity)

    # --- MODE 2: FUSE BY NAME ---
    await fuse_by_name(message, user_id, query)


async def bulk_fuse_rarity(message, user_id, rarity):
    # 1. Fetch Cards
    inventory = await db.fetch("""
        SELECT uc.id, uc.card_id, c.name, uc.stars, c.image_url
        FROM user_cards uc
        JOIN cards c ON uc.card_id = c.card_id
        WHERE uc.user_id = $1 AND uc.stars = $2
        ORDER BY c.name
    """, user_id, rarity)

    if not inventory:
        return await message.reply(f"❌ You don't have any {rarity}⭐ cards.")

    # 2. Group by Name
    groups = {}
    for card in inventory:
        name = card['name']
        if name not in groups: 
            groups[name] = {
                "ids": [],
                "image": card['image_url']
            }
        groups[name]["ids"].append(card['id'])

    # 3. Calculate Fusions (Limit 1 per character)
    fusions_to_do = []
    total_cost = 0
    cost_per_fuse = FUSE_COSTS.get(rarity, 5000)

    for name, data in groups.items():
        ids = data["ids"]
        if len(ids) >= 3:
            batch = ids[:3]
            fusions_to_do.append({
                "name": name,
                "ids": batch,
                "image": data["image"]
            })
            total_cost += cost_per_fuse

    if not fusions_to_do:
        return await message.reply(f"❌ No duplicates found! Need 3 copies.")

    # 4. Check Funds
    user_coins = await db.fetchval("SELECT coins FROM users WHERE user_id=$1", user_id)
    if user_coins < total_cost:
        return await message.reply(f"❌ **Insufficient Funds!** Cost: {total_cost}")

    # 5. EXECUTE DB
    async with db.pool.acquire() as conn:
        async with conn.transaction():
            await conn.execute("UPDATE users SET coins = coins - $1 WHERE user_id = $2", total_cost, user_id)
            for fuse in fusions_to_do:
                ids = fuse['ids']
                await conn.execute("DELETE FROM user_cards WHERE id = ANY($1::int[])", ids[1:])
                await conn.execute("UPDATE user_cards SET stars = stars + 1, level = 1, xp = 0 WHERE id = $1", ids[0])

    # 6. SEND RESULT
    summary = "\n".join([f"• 3x {f['name']} ➔ 1x {rarity+1}⭐" for f in fusions_to_do])
    caption = (
        f"🧬 **FUSION SUCCESS!**\n"
        f"💸 Spent: {total_cost} coins\n\n"
        f"**Upgrades:**\n{summary}"
    )

    # --- IMAGE FIX HERE ---
    if len(fusions_to_do) == 1:
        path = fusions_to_do[0]['image']
        await send_safe_photo(message, path, caption)
    else:
        # Album Logic
        media_group = []
        for i, fuse in enumerate(fusions_to_do[:5]): # Limit 5
            path = fuse['image']
            cap = caption if i == 0 else ""
            
            media = get_input_media(path, cap)
            if media: media_group.append(media)
        
        if media_group:
            await message.answer_media_group(media_group)
        else:
            await message.reply(caption)


async def fuse_by_name(message, user_id, query_name):
    inventory = await db.fetch("""
        SELECT uc.id, uc.card_id, c.name, uc.stars, c.image_url
        FROM user_cards uc
        JOIN cards c ON uc.card_id = c.card_id
        WHERE uc.user_id = $1 AND c.name ILIKE $2
        ORDER BY uc.stars ASC
    """, user_id, f"%{query_name}%")

    if not inventory: return await message.reply(f"❌ You don't own '{query_name}'.")

    target_rarity = inventory[0]['stars']
    candidates = [c for c in inventory if c['stars'] == target_rarity]
    
    if len(candidates) < 3: return await message.reply(f"❌ Need 3 copies of {candidates[0]['name']} ({target_rarity}⭐).")
    if target_rarity >= 5: return await message.reply("🌟 Max Rarity!")

    cost = FUSE_COSTS.get(target_rarity, 5000)
    user_coins = await db.fetchval("SELECT coins FROM users WHERE user_id=$1", user_id)
    if user_coins < cost: return await message.reply(f"❌ Need {cost} coins!")

    # DB Execute
    burn_ids = [c['id'] for c in candidates[:3]]
    async with db.pool.acquire() as conn:
        async with conn.transaction():
            await conn.execute("UPDATE users SET coins = coins - $1 WHERE user_id = $2", cost, user_id)
            await conn.execute("DELETE FROM user_cards WHERE id = ANY($1::int[])", burn_ids[1:])
            await conn.execute("UPDATE user_cards SET stars = stars + 1, level = 1, xp = 0 WHERE id = $1", burn_ids[0])

    # Result
    card = candidates[0]
    txt = (
        f"🧬 **FUSION SUCCESS!**\n"
        f"3x {target_rarity}⭐ {card['name']} ➔ {target_rarity+1}⭐\n"
        f"💸 -{cost} coins"
    )
    
    await send_safe_photo(message, card['image_url'], txt)


# --- 🛠️ HELPER FUNCTIONS (The Magic Fix) ---

def is_cloud_id(path):
    # Strict check: No slashes, no dots, long length
    return "/" not in path and "." not in path and len(path) > 20

async def send_safe_photo(message, path, caption):
    try:
        if is_cloud_id(path):
            await message.reply_photo(path, caption=caption)
        elif path.startswith("http"):
            await message.reply_photo(path, caption=caption)
        else:
            # Local file
            await message.reply_photo(FSInputFile(path), caption=caption)
    except Exception as e:
        print(f"Fusion Image Error: {e}")
        await message.reply(caption) # Fallback to text

def get_input_media(path, caption):
    try:
        if is_cloud_id(path) or path.startswith("http"):
            return InputMediaPhoto(media=path, caption=caption)
        else:
            return InputMediaPhoto(media=FSInputFile(path), caption=caption)
    except:
        return None
