from aiogram import Router, types
from aiogram.filters import Command
from database.db import db

router = Router()

@router.message(Command("top", "leaderboard"))
async def cmd_top(message: types.Message):
    # 1. GET RICHEST PLAYERS (Most Coins)
    rich_list = await db.fetch("""
        SELECT username, coins 
        FROM users 
        ORDER BY coins DESC 
        LIMIT 5
    """)
    
    # 2. GET TOP COLLECTORS (Most Cards)
    # We join users with user_cards and count the rows
    collectors = await db.fetch("""
        SELECT u.username, COUNT(uc.id) as card_count
        FROM users u
        JOIN user_cards uc ON u.user_id = uc.user_id
        GROUP BY u.username
        ORDER BY card_count DESC
        LIMIT 5
    """)

    # --- FORMATTING THE MESSAGE ---
    text = "🏆 **ANIME TCG LEADERBOARD** 🏆\n\n"

    # Section 1: The Tycoons
    text += "💰 **Richest Players**\n"
    for i, user in enumerate(rich_list, 1):
        medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
        name = user['username'] or "Unknown"
        text += f"{medal} <b>{name}</b> — {user['coins']} coins\n"

    text += "\n" + "─" * 20 + "\n\n"

    # Section 2: The Collectors
    text += "🃏 **Top Collectors**\n"
    for i, user in enumerate(collectors, 1):
        medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
        name = user['username'] or "Unknown"
        text += f"{medal} <b>{name}</b> — {user['card_count']} cards\n"

    await message.answer(text, parse_mode="HTML")
