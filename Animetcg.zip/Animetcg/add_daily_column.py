import asyncio
from database.db import db

async def migrate():
    await db.connect()
    print("⏳ Adding daily timer to users table...")
    
    # Add a column that stores the exact time of the last claim
    # DEFAULT 'EPOCH' means "the beginning of time" (so they can claim immediately)
    await db.execute("""
        ALTER TABLE users 
        ADD COLUMN IF NOT EXISTS last_daily TIMESTAMP DEFAULT '1970-01-01 00:00:00';
    """)
    
    print("✅ Database Updated! Users can now claim rewards.")

if __name__ == "__main__":
    asyncio.run(migrate())
