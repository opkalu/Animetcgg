import asyncio
import aiohttp
import os
from database.db import db

# Settings
TIMEOUT = 5  

async def check_link(session, url):
    """
    Returns True if the link is GOOD.
    Returns False if the link is TRASH.
    """
    # 1. Telegram File ID Check (SAVE THESE!)
    # If it looks like a long random string without "/" or ".", it's likely a File ID.
    if "/" not in url and "." not in url and len(url) > 20:
        return True 

    # 2. Local File Check (assets/...)
    if not url.startswith("http"):
        return os.path.exists(url)

    # 3. Web URL Check (http://...)
    try:
        async with session.get(url, timeout=TIMEOUT) as response:
            if response.status == 200:
                return True
            return False
    except:
        return False

async def main():
    await db.connect()
    print("🧹 STARTING DATABASE CLEANUP...")
    
    # Fetch all cards
    cards = await db.fetch("SELECT card_id, name, image_url FROM cards")
    print(f"🔍 Scanning {len(cards)} cards...")
    
    deleted_count = 0
    
    async with aiohttp.ClientSession() as session:
        for card in cards:
            url = card['image_url']
            c_id = card['card_id']
            name = card['name']
            
            if not url:
                print(f"❌ Removing {name}: No Image URL")
                await force_delete(c_id)
                deleted_count += 1
                continue

            # Check validity
            is_valid = await check_link(session, url)
            
            if not is_valid:
                print(f"🗑️ Trashing {name}: Broken Link ({url})")
                await force_delete(c_id)
                deleted_count += 1

    print(f"\n🎉 CLEANUP COMPLETE!")
    print(f"🗑️ Deleted {deleted_count} trash cards.")

async def force_delete(card_id):
    """Deletes the card from inventories/market first, then the card itself."""
    try:
        # 1. Delete from Market (if you have a market table)
        await db.execute("DELETE FROM market WHERE card_id=$1", card_id)
        
        # 2. Delete from User Inventories
        await db.execute("DELETE FROM user_cards WHERE card_id=$1", card_id)
        
        # 3. Delete the Card Definition
        await db.execute("DELETE FROM cards WHERE card_id=$1", card_id)
        
    except Exception as e:
        print(f"⚠️ Error deleting ID {card_id}: {e}")

if __name__ == "__main__":
    asyncio.run(main())

