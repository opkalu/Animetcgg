import asyncio
from database.db import db

async def seed():
    await db.connect()
    
    # 1=Common, 2=Rare, 3=Epic, 4=Legendary, 5=Mythic
    # Using MyAnimeList CDN links which are stable globally
    new_cards = [
        # --- MYTHIC (5) ---
        ("Goku (MUI)", 5, "Dragon Ball Super", "https://cdn.myanimelist.net/images/characters/11/347648.jpg"),
        ("Saitama", 5, "One Punch Man", "https://cdn.myanimelist.net/images/characters/11/294388.jpg"),
        ("Rimuru Tempest (Demon Lord)", 5, "TenSura", "https://cdn.myanimelist.net/images/characters/4/374676.jpg"),

        # --- LEGENDARY (4) ---
        ("Monkey D. Luffy", 4, "One Piece", "https://cdn.myanimelist.net/images/characters/9/310307.jpg"),
        ("Naruto Uzumaki", 4, "Naruto", "https://cdn.myanimelist.net/images/characters/9/131317.jpg"),
        ("Ichigo Kurosaki", 4, "Bleach", "https://cdn.myanimelist.net/images/characters/2/298813.jpg"),
        ("Levi Ackerman", 4, "Attack on Titan", "https://cdn.myanimelist.net/images/characters/2/241413.jpg"),
        ("Gojo Satoru", 4, "Jujutsu Kaisen", "https://cdn.myanimelist.net/images/characters/16/424362.jpg"),

        # --- EPIC (3) ---
        ("Tanjiro Kamado", 3, "Demon Slayer", "https://cdn.myanimelist.net/images/characters/9/384253.jpg"),
        ("Eren Yeager", 3, "Attack on Titan", "https://cdn.myanimelist.net/images/characters/10/253675.jpg"),
        ("Zoro Roronoa", 3, "One Piece", "https://cdn.myanimelist.net/images/characters/3/100534.jpg"),
        ("Killua Zoldyck", 3, "Hunter x Hunter", "https://cdn.myanimelist.net/images/characters/2/327426.jpg"),
        ("Makima", 3, "Chainsaw Man", "https://cdn.myanimelist.net/images/characters/14/425501.jpg"),

        # --- RARE (2) ---
        ("Deku", 2, "My Hero Academia", "https://cdn.myanimelist.net/images/characters/7/299404.jpg"),
        ("Natsu Dragneel", 2, "Fairy Tail", "https://cdn.myanimelist.net/images/characters/10/118671.jpg"),
        ("Light Yagami", 2, "Death Note", "https://cdn.myanimelist.net/images/characters/6/63870.jpg"),
        ("Edward Elric", 2, "Fullmetal Alchemist", "https://cdn.myanimelist.net/images/characters/9/72533.jpg"),
        ("Megumin", 2, "Konosuba", "https://cdn.myanimelist.net/images/characters/14/330206.jpg"),

        # --- COMMON (1) ---
        ("Subaru Natsuki", 1, "Re:Zero", "https://cdn.myanimelist.net/images/characters/16/309252.jpg"),
        ("Kazuma Satou", 1, "Konosuba", "https://cdn.myanimelist.net/images/characters/12/306788.jpg"),
        ("Aqua", 1, "Konosuba", "https://cdn.myanimelist.net/images/characters/9/330349.jpg"),
        ("Sakura Haruno", 1, "Naruto", "https://cdn.myanimelist.net/images/characters/9/88219.jpg")
    ]

    print("🚀 Mass seeding database...")
    
    # Clear old junk cards first so you don't pull broken images
    await db.execute("DELETE FROM cards") 
    
    for name, rarity, source, url in new_cards:
        await db.execute("""
            INSERT INTO cards (name, rarity, anime_source, image_url) 
            VALUES ($1, $2, $3, $4)
        """, name, rarity, source, url)
        
    print(f"✅ Database refreshed with {len(new_cards)} high-quality cards!")

if __name__ == "__main__":
    asyncio.run(seed())
