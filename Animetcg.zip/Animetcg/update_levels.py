import asyncio
from database.db import db

async def migrate():
    await db.connect()
    print("⏳ Adding Leveling System...")
    
    # Add level and xp columns if they don't exist
    # Default Level = 1, Default XP = 0
    await db.execute("""
        ALTER TABLE user_cards 
        ADD COLUMN IF NOT EXISTS level INT DEFAULT 1,
        ADD COLUMN IF NOT EXISTS xp INT DEFAULT 0;
    """)
    
    print("✅ Database Upgraded: Cards can now level up!")

if __name__ == "__main__":
    asyncio.run(migrate())
