import asyncio
from database.db import db

async def migrate():
    await db.connect()
    print("⏳ Creating Market System...")
    
    # id: Unique ID for the listing (e.g., #105)
    # seller_id: Who is selling
    # card_id: Which card (References user_cards table)
    # price: Cost in coins
    await db.execute("""
        CREATE TABLE IF NOT EXISTS market (
            market_id SERIAL PRIMARY KEY,
            seller_id BIGINT,
            card_id INT, 
            price BIGINT,
            listed_at TIMESTAMP DEFAULT NOW()
        );
    """)
    
    print("✅ Market Tables Created!")

if __name__ == "__main__":
    asyncio.run(migrate())
