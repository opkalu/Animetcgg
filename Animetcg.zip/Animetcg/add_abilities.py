import asyncio
from database.db import db

async def migrate():
    await db.connect()
    print("⏳ Adding Ability System...")
    
    # Add 'ability' column to user_cards
    # It will store text like "Critical+", "Wild Fury", etc.
    await db.execute("ALTER TABLE user_cards ADD COLUMN IF NOT EXISTS ability TEXT DEFAULT NULL;")
    
    print("✅ Database Upgraded: Awakening unlocked!")

if __name__ == "__main__":
    asyncio.run(migrate())
