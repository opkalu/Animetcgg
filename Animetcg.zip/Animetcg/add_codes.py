import asyncio
from database.db import db

async def migrate():
    await db.connect()
    print("⏳ Creating Promo Code System...")
    
    # Table for Codes
    # code: The text to type (e.g., "FREECOINS")
    # reward: Amount of coins
    # uses: How many people can claim it (e.g., 10 people)
    await db.execute("""
        CREATE TABLE IF NOT EXISTS promo_codes (
            code TEXT PRIMARY KEY,
            reward INT,
            uses_left INT
        );
    """)
    
    # Table to track who claimed what (so they don't claim twice)
    await db.execute("""
        CREATE TABLE IF NOT EXISTS redeemed_codes (
            user_id BIGINT,
            code TEXT,
            PRIMARY KEY (user_id, code)
        );
    """)
    
    print("✅ Database Ready for Promo Codes!")

if __name__ == "__main__":
    asyncio.run(migrate())
