import asyncio
from database.db import db

async def migrate():
    await db.connect()
    print("⏳ Fixing Guild Member Roles...")
    
    try:
        # 1. Add the missing column
        await db.execute("ALTER TABLE guild_members ADD COLUMN IF NOT EXISTS role TEXT DEFAULT 'Member';")
        print("✅ Added 'role' column.")
        
        # 2. Update any existing null roles to 'Member' just in case
        await db.execute("UPDATE guild_members SET role = 'Member' WHERE role IS NULL;")
        
    except Exception as e:
        print(f"⚠️ Error: {e}")

    print("✅ Database Repair Complete.")

if __name__ == "__main__":
    asyncio.run(migrate())
