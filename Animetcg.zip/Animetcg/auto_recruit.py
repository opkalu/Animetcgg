import os
import requests
import time

# Settings
INPUT_FILE = "recruit_list.txt"
OUTPUT_FOLDER = "assets/cards"

# Ensure folder exists
if not os.path.exists(OUTPUT_FOLDER):
    os.makedirs(OUTPUT_FOLDER)

def search_and_download(name, rarity, element, anime):
    print(f"🔍 Hunting for: {name}...")
    
    # 1. Search Jikan (MyAnimeList) API - FREE, NO KEY
    url = f"https://api.jikan.moe/v4/characters?q={name}&limit=1"
    try:
        response = requests.get(url)
        if response.status_code != 200:
            print(f"⚠️ API Error {response.status_code}. Sleeping 2s...")
            time.sleep(2.0)
            return

        data = response.json()
        
        if not data.get('data'):
            print(f"❌ Could not find '{name}' on MyAnimeList.")
            return

        # 2. Get Best Image URL
        char_data = data['data'][0]
        image_url = char_data['images']['jpg']['image_url']
        
        # 3. Download Image
        img_data = requests.get(image_url).content
        
        # 4. Save with "Code Name"
        # We save it in a format the loader script understands:
        # Name__Rarity__Element__Anime.jpg
        safe_name = name.replace(" ", "_")
        safe_anime = anime.replace(" ", "_")
        safe_element = element.replace(" ", "_")
        
        filename = f"{safe_name}__{rarity}__{safe_element}__{safe_anime}.jpg"
        file_path = os.path.join(OUTPUT_FOLDER, filename)
        
        with open(file_path, 'wb') as handler:
            handler.write(img_data)
            
        print(f"✅ Captured: {filename}")
        
    except Exception as e:
        print(f"⚠️ Error processing {name}: {e}")

    # Respect API Limits (Avoid getting banned)
    time.sleep(1.0)

def main():
    if not os.path.exists(INPUT_FILE):
        print(f"❌ Create '{INPUT_FILE}' first!")
        # Create a dummy file to help the user
        with open(INPUT_FILE, "w") as f:
            f.write("Naruto Uzumaki | 5 | Naruto | Wind\n")
            f.write("Monkey D. Luffy | 5 | One Piece | Physical\n")
        print(f"ℹ️ I created a sample '{INPUT_FILE}' for you.")
        return

    print(f"📜 Reading {INPUT_FILE}...")
    with open(INPUT_FILE, 'r') as f:
        lines = f.readlines()

    for line in lines:
        if not line.strip(): continue # Skip empty lines
        
        # Parse Line: Name | Rarity | Anime | Element
        try:
            parts = [p.strip() for p in line.split('|')]
            
            if len(parts) != 4:
                print(f"⚠️ Skipping invalid line (Needs 4 parts): {line.strip()}")
                continue
                
            name = parts[0]
            rarity = parts[1]
            anime = parts[2]   # 3rd Item in text file
            element = parts[3] # 4th Item in text file
            
            # Pass to downloader
            search_and_download(name, rarity, element, anime)
            
        except ValueError:
            print(f"⚠️ Formatting error on line: {line.strip()}")

    print("\n🎉 Mission Complete. Images are in assets/cards/")
    print("👉 Now run 'python import_cards.py' to add them to the database.")

if __name__ == "__main__":
    main()
