import asyncio
from database.db import db

async def migrate():
    await db.connect()
    print("⏳ Repairing Guild Database...")
    
    # List of columns to ensure exist
    columns = [
        ("funds", "BIGINT DEFAULT 0"),
        ("level", "INT DEFAULT 1"),
        ("xp", "INT DEFAULT 0"),
        ("buff_xp", "INT DEFAULT 0"),
        ("buff_dmg", "INT DEFAULT 0")
    ]

    for col_name, col_type in columns:
        try:
            await db.execute(f"ALTER TABLE guilds ADD COLUMN IF NOT EXISTS {col_name} {col_type};")
            print(f"✅ Checked/Added column: {col_name}")
        except Exception as e:
            print(f"⚠️ Error on {col_name}: {e}")

    print("✅ Database Repair Complete.")

if __name__ == "__main__":
    asyncio.run(migrate())
