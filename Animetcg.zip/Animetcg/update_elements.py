import asyncio
from database.db import db

async def migrate():
    await db.connect()
    # 1. Add column
    await db.execute("ALTER TABLE cards ADD COLUMN IF NOT EXISTS element TEXT DEFAULT 'Neutral';")
    
    # 2. Assign random elements to existing cards so they aren't boring
    print("Assigning elements to existing cards...")
    await db.execute("UPDATE cards SET element = 'Fire' WHERE card_id % 3 = 0;")
    await db.execute("UPDATE cards SET element = 'Water' WHERE card_id % 3 = 1;")
    await db.execute("UPDATE cards SET element = 'Leaf' WHERE card_id % 3 = 2;")
    
    print("✅ Database upgraded to Elemental System!")

if __name__ == "__main__":
    asyncio.run(migrate())
