import asyncio
import aiohttp
import os
import random
from dotenv import load_dotenv
from database.db import db

# Load environment variables
load_dotenv()
API_KEY = os.getenv("WAIFU_IM_TOKEN")

# Names to assign to the random images (Since API doesn't give names)
# We will combine these with the Image ID to make unique cards
PREFIXES = ["Dark", "Holy", "Cyber", "Mystic", "Battle", "School", "Royal", "Shadow"]
CLASSES = ["Knight", "Mage", "Archer", "Healer", "Assassin", "Princess", "Valkyrie", "Idol"]

async def fetch_waifus():
    url = "https://api.waifu.im/search"
    
    # correct params for v5 api
    params = {
        "many": "true",       # Ask for multiple images
        "limit": 30,          # Get 30 at a time
        "included_tags": "waifu" # valid tag
    }
    
    headers = {
        "User-Agent": "AnimeTCG/1.0"
    }
    
    # Only add the token if it actually exists
    if API_KEY:
        print(f"🔑 API Key found: {API_KEY[:5]}*******")
        headers["Authorization"] = f"Bearer {API_KEY}"
    else:
        print("⚠️ No API Key found in .env! Running in free mode (limited).")

    async with aiohttp.ClientSession() as session:
        print(f"📡 Requesting: {url}")
        async with session.get(url, headers=headers, params=params) as resp:
            if resp.status != 200:
                # READ THE ERROR MESSAGE FROM THE SERVER
                error_text = await resp.text()
                print(f"❌ API FAILED (Status {resp.status})")
                print(f"⚠️ Server Message: {error_text}")
                return []
            
            data = await resp.json()
            return data.get('images', [])

async def seed():
    await db.connect()
    
    print("🔄 Fetching fresh images from Waifu.im...")
    images = await fetch_waifus()
    
    if not images:
        print("❌ No images fetched. Aborting.")
        return

    print(f"🔥 Found {len(images)} images! Injecting into database...")
    
    # Optional: Clear old cards so you don't have duplicates
    # await db.execute("DELETE FROM cards") 

    count = 0
    for img in images:
        # 1. Get the Image URL
        image_url = img['url']
        image_id = img['image_id']
        
        # 2. Generate a cool name (e.g., "Cyber Valkyrie #3821")
        name = f"{random.choice(PREFIXES)} {random.choice(CLASSES)} #{image_id}"
        
        # 3. Generate Random Rarity (Weighted)
        rarity = random.choices([1, 2, 3, 4, 5], weights=[50, 30, 15, 4, 1])[0]
        
        # 4. Get Source (from tags)
        tags = [t['name'] for t in img.get('tags', [])]
        # Clean up tags to look like an anime title
        source = tags[0].replace("_", " ").title() if tags else "Original Art"

        # 5. Insert into DB (ON CONFLICT DO NOTHING ensures we don't crash if card exists)
        await db.execute("""
            INSERT INTO cards (name, rarity, anime_source, image_url)
            VALUES ($1, $2, $3, $4)
            ON CONFLICT DO NOTHING
        """, name, rarity, source, image_url)
        
        count += 1

    print(f"✅ Successfully added {count} new cards!")

if __name__ == "__main__":
    asyncio.run(seed())
