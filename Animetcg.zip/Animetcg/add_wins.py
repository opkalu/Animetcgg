import asyncio
from database.db import db

async def migrate():
    await db.connect()
    # Add wins/losses columns
    await db.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS wins INT DEFAULT 0;")
    await db.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS losses INT DEFAULT 0;")
    print("✅ Ranked System Ready!")

if __name__ == "__main__":
    asyncio.run(migrate())
