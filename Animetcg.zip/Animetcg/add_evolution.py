import asyncio
from database.db import db

async def migrate():
    await db.connect()
    print("⏳ Adding Evolution System...")
    
    # 1. Add 'stars' column to user_cards (This tracks the current rarity)
    await db.execute("ALTER TABLE user_cards ADD COLUMN IF NOT EXISTS stars INT;")
    
    # 2. Copy the base rarity from 'cards' table to 'user_cards' for all existing cards
    # This ensures no one loses their current star rating
    await db.execute("""
        UPDATE user_cards 
        SET stars = c.rarity 
        FROM cards c 
        WHERE user_cards.card_id = c.card_id AND user_cards.stars IS NULL;
    """)
    
    print("✅ Database Upgraded: Evolution unlocked!")

if __name__ == "__main__":
    asyncio.run(migrate())

